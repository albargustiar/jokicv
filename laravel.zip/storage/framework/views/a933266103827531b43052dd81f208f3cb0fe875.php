<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        /* CSS untuk mengatur halaman */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh; /* Memastikan halaman mencapai tinggi layar minimal */
        }

        /* CSS untuk mengatur tabel */
        table {
            margin-left: auto; /* Meletakkan tabel di paling kanan */
            margin-right: auto;
            width: 80%; /* Atur lebar tabel sesuai kebutuhan */
        }

        /* CSS untuk mengatur tata letak sidebar */
        .sidebar {
            margin-left: auto; /* Meletakkan sidebar di paling kanan */
            margin-right: 0;
        }
        table {
        border-collapse: separate;
        border-spacing: 0 20px; /* Jarak vertikal antara baris tabel */
        margin-left: auto;
        margin-right: auto;
        width: 50%;
        }
        hr {
            margin-top: 20px;
            margin-bottom: 20px;
            border: none;
            border-top: 1px solid #ccc;
        }
    
    </style>
</head>
<body>

    <!-- Admin Header -->
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Tabel Data -->
    <table border="1">  
        <?php $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <tr>
                    <td><strong>No.Pendaftar</strong></td>
                    <td><?php echo e($pdf->id); ?></td>
                </tr>
                <tr>
                    <td>Nama</td>
                    <td><?php echo e($pdf->nama); ?></td>
                </tr>
                <tr>
                    <td>Tempat, Tanggal Lahir</td>
                    <td><?php echo e($pdf->ttl); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td><?php echo e($pdf->jenis_kelamin); ?></td>
                </tr>
                <tr>
                    <td>Agama</td>
                    <td><?php echo e($pdf->agama); ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td><?php echo e($pdf->status); ?></td>
                </tr>
                <tr>
                    <td>No. Telp</td>
                    <td><?php echo e($pdf->no_telp); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td><?php echo e($pdf->alamat); ?></td>
                </tr>
                <tr>
                    <td>Riwayat Pendidikan</td>
                    <td><?php echo e($pdf->riwayat_pendidikan); ?></td>
                </tr>
                <tr>
                    <td>Pengalaman Kerja</td>
                    <td><?php echo e($pdf->pengalaman_kerja); ?></td>
                </tr>
                <tr>
                    <td>Sertifikasi</td>
                    <td><?php echo e($pdf->sertifikasi); ?></td>
                </tr>
                <tr>
                    <td>Pengalaman Organisasi</td>
                    <td><?php echo e($pdf->pengalaman_organisasi); ?></td>
                </tr>
                <tr>
                    <td>Soft Skill</td>
                    <td><?php echo e($pdf->soft_skill); ?></td>
                </tr>
                <tr>
                    <td>Hard Skill</td>
                    <td><?php echo e($pdf->hard_skill); ?></td>
                </tr>
                <tr>
                    <td colspan="2"> <hr> <br> <hr></td>
                </tr>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    

    <!-- Admin Sidebar -->
    <div class="sidebar">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

 

</body>
</html>
<?php /**PATH D:\project_laravel\coba2-laravel\resources\views/admin/index.blade.php ENDPATH**/ ?>