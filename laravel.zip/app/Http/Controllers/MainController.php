<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Pendaftaran; // Menggunakan model Pendaftaran

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    // Metode untuk menampilkan halaman utama
    public function index()
    {
        return view('main');
    }

    // Metode untuk menampilkan halaman admin
    public function adminIndex()
    {
        // Mendapatkan semua data Pendaftaran
        $pendaftarans = Pendaftaran::all();

        // Mengirim data ke view admin.index
        return view('admin.index', ['title' => 'Halaman Admin', 'pendaftarans' => $pendaftarans]);
    }
}
