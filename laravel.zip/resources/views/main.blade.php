
<!DOCTYPE html>
<html data-theme='light' dir='ltr' lang='en' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>

<!-- Mirrored from mauro-modern-fbt.blogspot.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 01 Feb 2024 16:55:30 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta content='width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1' name='viewport'/>
<title>JOKI CV</title>
<meta content='text/html; charset=UTF-8' http-equiv='Content-Type'/>
<!-- Chrome, Firefox OS and Opera -->
<meta content='#ffd2ba' name='theme-color'/>
<!-- Windows Phone -->
<meta content='#ffd2ba' name='msapplication-navbutton-color'/>
<meta content='blogger' name='generator'/>
<link href='favicon.ico' rel='icon' type='image/x-icon'/>
<link href='/' rel='canonical'/>
<link rel="alternate" type="application/atom+xml" title="Mauro - Atom" href="feeds/posts/default" />
<link rel="alternate" type="application/rss+xml" title="Mauro - RSS" href="feeds/posts/default9522?alt=rss" />
<link rel="service.post" type="application/atom+xml" title="Mauro - Atom" href="https://www.blogger.com/feeds/4441060079928558923/posts/default" />
<link rel="me" href="../../https://www.blogger.com/profile/17166328911298692516" />
<!--Can't find substitution for tag [blog.ieCssRetrofitLinks]-->
<meta content='https://mauro-modern-fbt.blogspot.com/' property='og:url'/>
<meta content='Mauro' property='og:title'/>
<meta content='Modern Blogger Theme' property='og:description'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgFmiCrYbELLKbIECi-R-vVfO5hQ8_YckpVQT4UfyK92jjEunwKiSBf5XSHp2jDR9h8IPPgP0Z6JoQpf1jEkBeOiNLMqyJ7bzvQo8abJYjfrOlBSZ3z8Kg-GoQEgpIIRXtkmyFULTYqQwJ67jLbefiPM2YYO40lGgds7tpnJcin9M1As9dQ9M0s5rke/w1200-h630-p-k-no-nu/img-1.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjVmLdYl9iR6EIflRd4HEhjcBxW6GyYXodQSpfqhXz2LdpyvnaEyjeGqrIP4ZcBWBz3qtEKf1sTOT3N5DS0yZLd3j-0l9b5J3QFBVl0J6mEg3AtoNDZpCatm2dJGCVoU_UsDjqYc38B_soAtpzG8pPbx8PRhhFm7ptKDmTJOG4t15S-ZV-3ypWOHjJI/w1200-h630-p-k-no-nu/img-2.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEheQST7eJIEiN2KaBcTzlVARzZGfzBgh9TduOhWENP_MSfOWEjuv_teHnIaG-_avYppm7ujNGuO12uz0ITgRNx_3cud0vB-e1l_6sdJtLt8gWvyFMt887mQ4-HkTVRw2ELlU--27OZSBeTHjbVUBSboOApLMGDbbmj9mass9RzMrpsM4OZtfvD-LjiN/w1200-h630-p-k-no-nu/img-3.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiw5LgDsuoTb2SnUrCR9VV_T_-9ZjnmK39lhMWdslZ3widEFJxYsC_LyldW7PGY37-ZuntrbTEDiYnlEPuKjbwjCT3c2CUrC2zMRPtwiPCbil81q5UIUQkdayG13tnkYEEWt2-XOPPlILEVgnMNC9q643dHdjHwMDHrHjeabEu72LGgXky-aOrhYVDi/w1200-h630-p-k-no-nu/img-4.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjt9h4jifkTkmVwyMftjet4txtcEfhSy0qB3J-s1s4V6qh_xLg2g_YesVtYyFkdXEkf_jWDso9Ckfn7TE6nu6i9Vq_LKUZ6nZfdu9--e5hEurE6zi0vyQVPWuioB0BO-fft-rpWVp6R8jcw6OS0HIX9r_nj2qAHZmBenYRHoB_32rvXMb4Zk_jovvbo/w1200-h630-p-k-no-nu/img-5.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEge6Q1gfWBbCGCUylhCyi7Um42lsTywUACiT3dNL2xWKJLsjY5IGUeJRMTC9R3kPkWA7MumbWjKjuWkbhYL3Kx33ZSZG4GuFnviijpyaxD5gJd2aQ6Uodai4m1t-4wf1eopOGWDkpgIR-2uHeIjLpVrjppdVuAnyVo7nbR9YVfgKvBJSi1meS2wRsl3/w1200-h630-p-k-no-nu/img-6.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiRA8DDCEkqS9FIMh5FkfKKlGrwLPqJH26Zr03a09T2NBMFoET1lVA-PVqr7hI8gKTOIY76tb7lSLn71KzkwjYqCUkpDUZqNR3W7yyYz3m_Np3ihD__uxGWdGRGXkS0gDATKi0CutyP7idzO9SmogSVQkzGFuLZoHyudkaWg4am2pgPgkuDEGt4yFoA/w1200-h630-p-k-no-nu/img-7.jpg' property='og:image'/>
<meta content='https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgLjgmnDH0A0aKZzxORHos5OTnTrLyNw6AOy4x1cc0hvi2j8DuZR7d72-a4Lkekx4A2vSgYHFrWUcqJ-hugjDJHgHIOinynfqbmPS71tW0rPh5CRapmadHW6R6Xqar87qGnMgi4zR2LTbFgqNDfodwF982U0dD5tOThp6CgDE1o27zxscixIHI2mOnf/w1200-h630-p-k-no-nu/img-8.jpg' property='og:image'/>
<script>
      //<![CDATA[
		let localS = localStorage.getItem('theme');if (localS === 'dark') {document.documentElement.setAttribute('data-theme', 'dark');}
  	  //]]>
	</script>
<link href='https://fonts.googleapis.com/' rel='preconnect'/>
<link href='https://fonts.gstatic.com/' rel='preconnect'/>
<link href='https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&amp;display=swap' rel='stylesheet'/>
<link href='../../use.fontawesome.com/releases/v6.4.2/css/all1e39.css?ver=6.4.2' rel='stylesheet'/>
<link href='../../maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min1849.css?ver=4.7.0' rel='stylesheet'/>
<link href='../../cdn.jsdelivr.net/npm/bootstrap%404.6.2/dist/css/bootstrap.min83b6.css?ver=4.6.2' rel='stylesheet'/>
<script src='../../ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min5aed.js?ver=3.6.4'></script>
<style type='text/css'>@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;src:url(http://fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2)format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2)format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:400;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2)format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2)format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:600;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459WRhyzbi.woff2)format('woff2');unicode-range:U+0460-052F,U+1C80-1C88,U+20B4,U+2DE0-2DFF,U+A640-A69F,U+FE2E-FE2F;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459W1hyzbi.woff2)format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459WZhyzbi.woff2)format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459Wdhyzbi.woff2)format('woff2');unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF;}@font-face{font-family:'Montserrat';font-style:normal;font-weight:700;src:url(//fonts.gstatic.com/s/montserrat/v26/JTUSjIg1_i6t8kCHKm459Wlhyw.woff2)format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD;}</style>
<style id='page-skin-1' type='text/css'><!--
/**********************************************************************
____________________________  _____________  __________________________
|   __|  __ \_    _|  ___|  \/  |   _  |  |  |     |_    _|  ___/  ___/
|  |__|  __ < |  | |  ___|      |   ___|  |__|  -  | |  | |  ___|___  \
|__|  |_____/ |__| |_____|__||__|__|   |_____|__|__| |__| |_____/_____/
Blogger Template Style
Theme Name:   Mauro
Author:       fbtemplates
Author Url:   https://fbtemplates.net - https://themeforest.net/user/fbtemplates/portfolio
************************************************************************
************************************************************************/
@media (min-width: 1200px) {
.fbt-main-wrapper {
flex: 0 0 72%;
max-width: 72%;
}
.sidebar-wrapper {
flex: 0 0 28%;
max-width: 28%;
}
.header-widget {
            text-align: center;
        }

        .header-image-wrapper {
            display: inline-block;
        }

        .header-image-wrapper img {
            height: 120px;
            animation: bounce 1s infinite; /* Menetapkan animasi bounce */
        }

        /* Membuat keyframes untuk animasi bounce */
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {
                transform: translateY(0);
            }
            40% {
                transform: translateY(-30px);
            }
            60% {
                transform: translateY(-15px);
            }
        }
}
:root {
--h1-font: 700 26px Montserrat, sans-serif;
--h2-font: 700 24px Montserrat, sans-serif;
--h3-font: 700 22px Montserrat, sans-serif;
--h4-font: 700 20px Montserrat, sans-serif;
--h5-font: 700 18px Montserrat, sans-serif;
--h6-font: 700 16px Montserrat, sans-serif;
--index-text-font: 400 14px Montserrat, sans-serif;
--item-text-font: 400 16px Montserrat, sans-serif;
--meta-text-font: 600 13px Montserrat, sans-serif;
--widget-title-font: 700 20px Montserrat, sans-serif;
--footer-widget-title-font: 700 15px Montserrat, sans-serif;
--header-H1-font: 700 34px Montserrat;
--menu-font: 700 13px Montserrat, sans-serif;
--dropdown-menu-font: 700 12px Montserrat, sans-serif;
--primary: #ebccff;
--secondary: #ffe6d9;
--success: #d9fdd0;
--info: #dbeeff;
--warning: #fff5cf;
--danger: #ff005b;
--light: #f8f9fa;
--dark: #343a40;
--white: #ffffff;
--color-1: #FFCDB2;
--color-2: #FFB4A2;
--color-3: #E5989B;
--color-4: #B5838D;
--color-5: #6D6875;
--menu-trans: uppercase;
--grid-gap: 40px;
--block-radius: 23px;
--header-margin: 60px;
--theme-transition: color .3s ease-in-out, background-color .3s ease-in-out, background-image .3s ease-in-out, border-color .3s ease-in-out, border-width .3s ease-in-out, fill .3s ease-in-out, transform .3s ease-in-out, padding .3s ease-in-out, margin .3s ease-in-out, stroke .3s ease-in-out;
}
:root[dir='rtl'] {
--h1-font: 700 26px 'Cairo', sans-serif;
--h2-font: 700 24px 'Cairo', sans-serif;
--h3-font: 700 22px 'Cairo', sans-serif;
--h4-font: 700 20px 'Cairo', sans-serif;
--h5-font: 700 18px 'Cairo', sans-serif;
--h6-font: 700 16px 'Cairo', sans-serif;
--index-text-font: 400 14px 'Cairo', sans-serif;
--item-text-font: 400 16px 'Cairo', sans-serif;
--meta-text-font: 600 13px 'Cairo', sans-serif;
--widget-title-font: 700 20px 'Cairo', sans-serif;
--footer-widget-title-font: 700 15px 'Cairo', sans-serif;
--header-H1-font: 700 34px 'Cairo', sans-serif;
--menu-font: 400 14px 'Cairo', sans-serif;
--dropdown-menu-font: 400 12px 'Cairo', sans-serif;
}
:root[data-theme='light'] {
--border-color: #000000;
--search-border-color: #000000;
--body-text-color: #000000;
--body-link-color: #000000;
--black: #000000;
--main-color: #B5838D;
--header-bg-color: #fff5cf;
--site-title-color: #333333;
--scrolling-nav-bg-color: #fff5cf;
--scrolling-site-title-color: #000000;
--main-menu-color: #000000;
--scrolling-menu-color: #282828;
--headline-color: #000000;
--headline-hover-color: #333333;
--headline-bg-color-start: #ffffff;
--headline-bg-color-end: #ffffff;
--title-color: #000000;
--dropdown-menu-bg: #fff5cf;
--dropdown-menu-color: #333333;
--dropdown-hover-link-color: #000000;
--dropdown-hover-link-bg-color: #dbeeff;
--post-text-color: #000000;
--meta-text-color: #333333;
--comments-bg-color: #ebccff;
--left-side: #ffffff;
--left-side-triangle: transparent;
--right-side: transparent;
--gradient-color: transparent;
--widget-title-color: #000000;
--left-side-border-color: #000000;
--right-side-border-color: #000000;
--footer-bg-color: #fff5cf;
--footer-widget-title-color: #000000;
--footer-text-color: #000000;
--footer-hover-text-color: #B5838D;
--credits-divider-color: #000000;
--switcher-background: #ffe6d9;
--switcher-circle-background: #85d0ef;
--sun-color: #eeff00;
--moon-color: #999999;
}
:root[data-theme='dark'] {
--border-color: #555555;
--body-dark: #000000;
--search-border-color: #555555;
--body-text-color: #ffffff;
--body-link-color: #ffffff;
--black: #ffffff;
--main-color: #E5989B;
--header-bg-color: #000000;
--site-title-color: #ffffff;
--scrolling-nav-bg-color: #000000;
--scrolling-site-title-color: #ffffff;
--main-menu-color: #ffffff;
--scrolling-menu-color: #ffffff;
--headline-color: #ffffff;
--headline-hover-color: #E5989B;
--headline-bg-color-start: #000000;
--headline-bg-color-end: #000000;
--title-color: #ffffff;
--dropdown-menu-bg: #222222;
--dropdown-menu-color: #ffffff;
--dropdown-hover-link-color: #ffffff;
--dropdown-hover-link-bg-color: #333333;
--post-text-color: #ffffff;
--meta-text-color: #ffffff;
--comments-bg-color: #222222;
--left-side: transparent;
--left-side-triangle: transparent;
--right-side: transparent;
--gradient-color: transparent;
--widget-title-color: #ffffff;
--left-side-border-color: #555555;
--right-side-border-color: #555555;
--footer-bg-color: #000000;
--footer-widget-title-color: #ffffff;
--footer-text-color: #ffffff;
--footer-hover-text-color: #E5989B;
--credits-divider-color: #555555;
--switcher-background: #333333;
--switcher-circle-background: rgba(255, 255, 255, 0.2);
--sun-color: #999999;
--moon-color: #FEFCD7;
}
.badge-primary,
.bg-primary {
background-color: var(--primary) !important;
}
.badge-secondary,
.bg-secondary {
background-color: var(--secondary) !important;
}
.badge-success,
.bg-success {
background-color: var(--success) !important;
}
.badge-info,
.bg-info {
background-color: var(--info) !important;
}
.badge-warning,
.bg-warning {
background-color: var(--warning) !important;
}
.badge-danger,
.bg-danger {
background-color: var(--danger) !important;
}
.badge-light,
.bg-light {
background-color: var(--light) !important;
}
.badge-dark,
.bg-dark {
background-color: var(--dark) !important;
}
.badge-gradient,
.bg-gradient {
background-image: linear-gradient(90deg,#ebccff,#ff005b);
}
.btn-primary:not(:disabled):not(.disabled):active,
.btn-primary:not(:disabled):not(.disabled).active,
.show > .btn-primary.dropdown-toggle,
.btn-primary,
.btn-primary:hover {
background-color: var(--primary);
border-color: var(--primary);
}
.btn-secondary:not(:disabled):not(.disabled):active,
.btn-secondary:not(:disabled):not(.disabled).active,
.btn-secondary,
.btn-secondary:hover {
background-color: var(--secondary);
border-color: var(--secondary);
}
.btn-success:not(:disabled):not(.disabled):active,
.btn-success:not(:disabled):not(.disabled).active,
.btn-success,
.btn-success:hover {
background-color: var(--success);
border-color: var(--success);
}
.btn-info:not(:disabled):not(.disabled):active,
.btn-info:not(:disabled):not(.disabled).active,
.btn-info,
.btn-info:hover {
background-color: var(--info);
border-color: var(--info);
}
.btn-warning:not(:disabled):not(.disabled):active,
.btn-warning:not(:disabled):not(.disabled).active,
.btn-warning,
.btn-warning:hover {
background-color: var(--warning);
border-color: var(--warning);
}
.btn-danger:not(:disabled):not(.disabled):active,
.btn-danger:not(:disabled):not(.disabled).active,
.btn-danger,
.btn-danger:hover {
background-color: var(--danger);
border-color: var(--danger);
}
.btn-light:not(:disabled):not(.disabled):active,
.btn-light:not(:disabled):not(.disabled).active,
.btn-light,
.btn-light:hover {
background-color: var(--light);
border-color: var(--light);
}
.btn-dark:not(:disabled):not(.disabled):active,
.btn-dark:not(:disabled):not(.disabled).active,
.btn-dark,
.btn-dark:hover {
background-color: var(--dark);
border-color: var(--dark);
}
.btn-search,
.btn-search:hover {
background-color: var(--color-4);
border-color: var(--color-4);
color: var(--white);
}
.border {
border: 1px solid #000000 !important;
}
.border-top {
border-top: 1px solid #000000 !important;
}
.border-right {
border-right: 1px solid #000000 !important;
}
.border-bottom {
border-bottom: 1px solid #000000 !important;
}
.border-left {
border-left: 1px solid #000000 !important;
}
::selection {
text-decoration: none;
background-color: var(--color-4);
color: var(--white);
}
.text-main {
color: var(--main-color);
}
/* General
===================================== */
*,
*::before,
*::after {
word-break: break-word;
box-sizing: border-box;
}
.hidden {display: none;}
.container .container {padding: 0;}
button:focus,
button:active:focus,
button.active {
outline: none;
-webkit-box-shadow: none;
box-shadow: none;
}
a.badge:focus {
outline: 0;
box-shadow: none;
}
p {
margin-bottom: 25px;
}
.radius-0 {
border-radius: 0;
}
.fbt-post-thumbnail,
.fbt-item-thumbnail,
.fbt-item-thumbnail-single,
.post-content img,
.radius-10 {
border-radius: 23px!important;
overflow: hidden!important;
}
.radius-25 {
border-radius: 25px!important;
overflow: hidden!important;
}
.o-visible {
overflow: visible!important;
}
.list-unstyled li a {
padding: .4rem 0;
display: block;
}
.list-unstyled li:first-child a {
padding-top: 0;
}
.list-unstyled li:last-child a {
padding-bottom: 0;
}

.fbt-resize {
width: 100%;
max-width: 100%;
height: 100%;
max-height: 100%;
position: relative;
background-position: center;
-webkit-background-size: cover;
-moz-background-size: cover;
background-size: cover;
-o-background-size: cover;
}
:focus {outline: 0;}
.divider {position: relative;transition: var(--theme-transition);}
.divider:before {
margin-bottom: 1.5rem;
display: block;
width: 100%;
height: 1px;
content: '';
background: var(--credits-divider-color);
opacity: .6;
transition: var(--theme-transition);
}
.divider.top:before {
margin-bottom: 0;
height: 0px;
}
@media (min-width: 1365.98px) {
.container {
max-width: 1270px;
}
.canvas-modern .slider-container .FeaturedPostContainer .container {
max-width: calc(1270px + 30px);
}
}
#page-wrapper {
background-color: transparent;
max-width: 2500px;
margin-top: 0px;
margin-bottom: 0px;
margin-left: auto;
margin-right: auto;
box-shadow: 0 0 0px rgba(23,16,159,.15);
position: relative;
}
@media (max-width: 1365.98px) {
.text-responsive {
font-size: calc(150% + 1vw + 1vh)!important;
}
}
@media (max-width: 991.98px) {
.fbt-main-wrapper {
margin-bottom: 60px;
}
.home:not(.canvas-modern) .fbt-main-wrapper {
margin-bottom: 0;
}
}
.btn:hover {
opacity: .9;
}
blockquote {
margin: 0 0 25px;
}
blockquote .card {
background-color: var(--color-1);
border-radius: 0;
}
[data-theme='dark'] blockquote .card {
background-color: var(--dark);
}
blockquote p {
position: relative;
color: var(--black);
}
blockquote p:before {
content: '\f10d';
color: var(--black);
font-size: 3.7em;
opacity: .1;
font-family: FontAwesome;
position: absolute;
top: -10px;
left: -25px;
}
.CSS_LIGHTBOX {
z-index: 9999!important;
}
.CSS_LAYOUT_COMPONENT.CSS_LIGHTBOX_ATTRIBUTION_INDEX_CONTAINER {
display: none;
}
#cookieChoiceInfo {
bottom: 0;
top:auto;
background: var(--white);
box-shadow: 0 4px 30px rgba(0,0,0,0.1);
}
[data-theme='dark'] #cookieChoiceInfo {
background: var(--dark);
}
.cookie-choices-info .cookie-choices-text {
font-size: 12px!important;
color: var(--black)!important;
}
.cookie-choices-info .cookie-choices-button {
text-transform: capitalize!important;
color: var(--white);
background: var(--color-4);
font-weight: 300!important;
padding: .75rem 1.2rem!important;
}
.cookie-choices-info .cookie-choices-button a {
padding: 0!important;
}
@media (min-width: 1200px) {
.fbt-sticky-content {
top: 95px;
}
}
@media (max-width: 1199.98px) {
.fbt-sticky-content {
top: 10px;
}
}
body {
background: #ffd2ba none no-repeat scroll center center;
color: var(--body-text-color);
font: var(--index-text-font);
overflow-x: hidden;
transition: var(--theme-transition);
}
[data-theme="dark"] body {
background: var(--body-dark);
}
a {
color: var(--black);
-webkit-transition: color .20s, background .20s, opacity .20s;
transition: color .20s, background .20s, opacity .20s;
}
a .fa,a .fab,a .fad,a .fal,a .far,a .fas {
font-size: calc(14px + 1px);
}
a:hover h1, a:hover h2, a:hover h3, a:hover h4, a:hover h5, a:hover h6, a:hover .h1, a:hover .h2, a:hover .h3, a:hover .h4, a:hover .h5, a:hover .h6,
a:hover {
color: var(--main-color);
text-decoration: none;
}
p {line-height: 1.6em;}
/* Bootstrap Buttons
===================================== */
.btn:focus,
.btn.focus {box-shadow: none;}
.btn:not(:disabled):not(.disabled):active:focus,
.btn:not(:disabled):not(.disabled).active:focus {-webkit-box-shadow: none;box-shadow: none;}
/* Typography
===================================== */
h1, h2, h3, h4, h5, h6, h1 a, h2 a, h3 a, h4 a, h5 a, h6 a, .h1, .h2, .h3, .h4, .h5, .h6 {color: var(--title-color);margin: 0;}
h1, .h1 {font: var(--h1-font);line-height: 1.25;}
h2, .h2 {font: var(--h2-font);line-height: 1.25;}
h3, .h3 {font: var(--h3-font);line-height: 1.25;}
h4, .h4 {font: var(--h4-font);line-height: 1.25;}
h5, .h5 {font: var(--h5-font);line-height: 1.25;}
h6, .h6 {font: var(--h6-font);line-height: 1.25!important;}
/* Widget Settings
===================================== */
.canvas-modern .sidebar-wrapper {
display: block;
}
.sidebar-wrapper .widget,
#footer-content .widget {
margin: 60px 0;
line-height: 100%;
}
@media (max-width; 991.98px) {
.sidebar-wrapper .widget,
#footer-content .widget {
margin: calc(60px - 20px) 0;
}
}
.sidebar-wrapper .section:first-child .widget:first-child,
#footer-content .section:first-child .widget:first-child {
margin-top: 0;
}
.sidebar-wrapper .section:last-child .widget:last-child,
#footer-content .section:last-child .widget:last-child {
margin-bottom: 0;
}
.fbt-sep-title {
display: -webkit-box;
display: -webkit-flex;
display: -ms-flexbox;
display: flex;
-webkit-flex-wrap: nowrap;
-ms-flex-wrap: nowrap;
flex-wrap: nowrap;
-ms-align-items: center;
-webkit-box-align: center;
-webkit-align-items: center;
-ms-flex-align: center;
align-items: center;
margin: 0 0 30px;
overflow: hidden;
}
.fbt-sep-title .title-sep-container {
position: relative;
height: 1px;
-ms-flex-grow: 1;
-webkit-box-flex: 1;
-webkit-flex-grow: 1;
-ms-flex-positive: 1;
flex-grow: 1;
}
.fbt-sep-title .title-sep.sep-double {
height: 1px;
}
.fbt-sep-title .title-sep {
background-color: var(--right-side);
background-image: linear-gradient(45deg, var(--gradient-color) 25%, transparent 25%, transparent 50%, var(--gradient-color) 50%, var(--gradient-color) 75%, transparent 75%, transparent);
background-size: 6px 6px;
transition: var(--theme-transition);
}
.fbt-sep-title .title-sep {
position: relative;
display: block;
width: 100%;
border-bottom: 1px solid var(--right-side-border-color);
border-top: 0px solid var(--right-side-border-color);
}
.fbt-sep-title h1.title-heading-left, .fbt-sep-title h2.title-heading-left, .fbt-sep-title h3.title-heading-left, .fbt-sep-title h4.title-heading-left, .fbt-sep-title h5.title-heading-left, .fbt-sep-title h6.title-heading-left {
text-align: left;
display: block!important;
}
.fbt-sep-title h4.title-heading-left {
font: var(--widget-title-font);
background-color: var(--left-side);
color: var(--widget-title-color);
height: 30px;
line-height: 18px;
padding: 0 0px 0 0px;
position: relative;
border-bottom: 1px solid var(--left-side-border-color);
border-top: 0px solid var(--left-side-border-color);
transition: var(--theme-transition);
}
.fbt-sep-title h4.title-heading-left:after {
left: 100%;
top: 0;
height: 0;
width: 0;
position: absolute;
content: " ";
pointer-events: none;
margin-left: 0;
margin-top: 0;
border-bottom: 30px solid var(--left-side-triangle);
border-right: 20px solid transparent;
z-index: 1;
}
.widget.Followers h2 {
font: var(--widget-title-font);
margin: 0 0 30px;
}
/* Navbar Header
===================================== */
.navbar-brand {
font-size: 1rem;
}
#LinkList1 {min-height: 95px;}
#LinkList1 ul {list-style: none;}
#LinkList1 ul li {display: none;}
header {
margin-bottom: 60px;
}
@media (max-width: 991.98px) {
header {
margin-bottom: calc(60px - 20px);
}
}
.dropdown-toggle::after {
content: "\f078";
font-family: fontAwesome;
border: 0;
font-size: 8px;
margin-left: 3px;
font-weight: normal;
}
.dropdown .nav-link {
outline: 0;
}
.dropdown-menu,
.dropdown .dropdown-menu {
-webkit-box-shadow: 0 4px 30px rgba(0, 0, 0, 0.09);
box-shadow: 0 4px 30px rgba(0, 0, 0, 0.09);
background: var(--dropdown-menu-bg);
margin: 0 0 0;
padding: .8rem 0;
border: 0;
min-width: 14rem;
border-radius: calc(var(--block-radius) - 12px);
z-index: 1030;
}
@media (max-width: 991.98px) {
.dropdown .dropdown-menu {
padding: 0;
margin: 0;
background: transparent;
-webkit-box-shadow: none;
box-shadow: none;
}
}
.dropdown .dropdown-menu .dropdown-item {
position: relative;
padding: .49rem 1.2rem .47rem calc(1.2rem - 3px);
font: var(--dropdown-menu-font);
color: var(--dropdown-menu-color);
border-left: 3px solid transparent;
transition: all .25s cubic-bezier(.32,.74,.57,1);
text-transform: var(--menu-trans);
}
@media (max-width: 991.98px) {
.dropdown .dropdown-menu .dropdown-item {
padding: .49rem 1rem .47rem calc(1rem - 3px);
}
}
.dropdown .dropdown-menu .dropdown-item:hover,
.dropdown .dropdown-menu .dropdown-item:focus {
background-color: var(--dropdown-hover-link-bg-color)!important;
color: var(--dropdown-hover-link-color);
border-left: 3px solid var(--main-color);
}
.dropdown .dropdown-menu .dropdown-item:focus {
background: var(--main-color);
}
@media (max-width: 991.98px) {
.dropdown .dropdown-menu .dropdown-item {
color: var(--main-menu-color);
}
.dropdown .dropdown-menu .dropdown-item:hover, .dropdown .dropdown-menu .dropdown-item:focus {
background: transparent!important;
color: var(--main-menu-color);
opacity: .85;
}
}
.dropdown.fbt-megamenu {
position: static;
}
.dropdown.fbt-megamenu .fullwidth {
width: 100%;
margin: 0;
}
@media (min-width: 992px) {
.dropdown:hover .dropdown-menu {
display: block;
}
.navbar {
padding-top: 0;
padding-bottom: 0;
}
}
.navbar .nav-link {
font: var(--menu-font);
text-transform: var(--menu-trans);
}
@media (min-width: 992px) {
.navbar .nav-link {
padding-top: 39px;
padding-bottom: 39px;
}
.navbar .dropdown-menu {
-webkit-animation: dropdown .2s ease forwards;
animation: dropdown .2s ease forwards;
}
.navbar .dropdown-menu .nav-link {
padding-top: 0.5rem;
padding-bottom: 0.5rem;
}
}
@-webkit-keyframes dropdown {
0% {
opacity: 0;
-webkit-transform: translateY(1rem);
transform: translateY(1rem);
}
100% {
opacity: 1;
-webkit-transform: translateY(0);
transform: translateY(0);
}
}
@keyframes dropdown {
0% {
opacity: 0;
-webkit-transform: translateY(1rem);
transform: translateY(1rem);
}
100% {
opacity: 1;
-webkit-transform: translateY(0);
transform: translateY(0);
}
}
@media (min-width: 992px) {
.header-buttons {
border-left: 1px solid var(--search-border-color);
padding-left: 27px;
margin-left: 27px;
line-height: calc(17px + 11px);
height: calc(17px + 11px);
transition: var(--theme-transition);
}
}
.navbar-search {
font-size: 17px;
cursor: pointer;
}
.fbt-close-icon {
font-size: calc(17px + 4px);
padding-top: 3px;
}
@media(max-width: 991.98px) {
.navbar-search {
font-size: calc(17px + 3px);
}
.fbt-close-icon {
font-size: calc(17px + 15px);
}
}
.fbt-close-icon:before {
content: '\00d7';
}
.fbt-sidenav svg {
height: calc(17px - 7px);
width: calc(17px - 7px);
margin-top: -4px;
}
.navbar-dark .navbar-nav .nav-link {
padding-left: 1.2rem;
padding-right: 1.2rem;
}
.navbar-dark .navbar-nav .nav-item:last-child .nav-link {
padding-right: 0;
}
@media(max-width: 991.98px) {
.navbar-dark .navbar-nav .nav-link {
padding-left: 0;
padding-right: 0;
}
}
.navbar-dark .navbar-nav .nav-link,
.navbar-dark .navbar-search {
color: var(--main-menu-color);
}
.navbar-dark .fbt-sidenav svg {
fill: var(--main-menu-color);
}
.navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link:focus {
color: var(--main-menu-color);
opacity: .85;
}
.fbt_sticky_nav.nav_offset {
-webkit-transform: translate3d(0, -100%, 0);
transform: translate3d(0, -100%, 0);
-webkit-transition: all 0.3s ease-in-out;
transition: all 0.3s ease-in-out;
}
.fbt_sticky_nav.sticky__nav {
position: fixed;
visibility: hidden;
opacity: 0;
top: 0;
left: 0;
right: 0;
z-index: 1030;
}
.fbt_sticky_nav.sticky__nav.scrolling_nav {
opacity: 1;
visibility: visible;
}
.fbt_sticky_nav.scrolling_nav {
-webkit-transform: translate3d(0, 0, 0);
transform: translate3d(0, 0, 0);
}
@media (min-width: 992px) {
.fbt_sticky_nav.scrolling_nav .nav-item .nav-link {
padding-top: 1.5rem;
padding-bottom: 1.5rem;
}
}
.dark-skin {
background-color: var(--header-bg-color);
border-top: 1px solid var(--border-color);
border-bottom: 1px solid var(--border-color);
padding-left: 0;
padding-right: 0;
transition: var(--theme-transition);
}
@media (max-width: 991.98px) {
.navbar-expand-lg>.container {
padding-left: 15px;
padding-right: 15px;
}
}
.Header h1 {font: var(--header-H1-font);}
.Header h1 a {color: var(--site-title-color);}
.Header h1 a:hover {color: var(--main-color);}
.Header img {max-width: 130px;}
[data-theme='dark'] #Header1 {
display: none;
}
.light-logo {
display: none;
}
[data-theme='dark'] .light-logo {
display: block;
}
#LinkList1 {
width: 100%;
-ms-flex-preferred-size: 100%;
flex-basis: 100%;
-ms-flex-positive: 1;
flex-grow: 1;
-ms-flex-align: center;
align-items: center;
}
@media (min-width: 992px) {
#LinkList1 {
display: -ms-flexbox!important;
display: flex!important;
-ms-flex-preferred-size: auto;
flex-basis: auto;
}


}

.navbar-dark .navbar-toggler {
padding: 0.25rem 0;
font-size: 1.5rem;
line-height: 1;
background-color: transparent;
border: 0!important;
border-color: transparent!important;
border-radius: 0;
color: var(--main-menu-color);
}
.navbar-dark .navbar-toggler .navbar-icon {
stroke: var(--main-menu-color);
}
.navbar-dark .navbar-nav .active>.nav-link, .navbar-dark .navbar-nav .nav-link.active, .navbar-dark .navbar-nav .nav-link.show, .navbar-dark .navbar-nav .show>.nav-link {
color: var(--main-menu-color);
}
.fbt_sticky_nav.sticky__nav.scrolling_nav {
background: var(--scrolling-nav-bg-color);
border-top: 0;
}
.navbar-dark.fbt_sticky_nav.sticky__nav.scrolling_nav .fbt-sidenav,
.navbar-dark.fbt_sticky_nav.sticky__nav.scrolling_nav .navbar-nav .nav-link,
.navbar-dark.fbt_sticky_nav.sticky__nav.scrolling_nav .navbar-search {
color: var(--scrolling-menu-color);
}
.navbar-dark.fbt_sticky_nav.sticky__nav.scrolling_nav .fbt-sidenav svg {
fill: var(--scrolling-menu-color);
}
.fbt_sticky_nav.sticky__nav.scrolling_nav .Header h1 a {
color: var(--scrolling-site-title-color);
}
.dropdown .dropdown-menu:before {
position: absolute;
z-index: -1;
bottom: 100%;
left: 15px;
display: block;
width: 18px;
height: 18px;
content: '';
-webkit-transform: rotate(-45deg) translateY(1rem);
transform: rotate(-45deg) translateY(1rem);
border-radius: .19rem;
background: var(--dropdown-menu-bg);
-webkit-box-shadow: none;
box-shadow: none;
}
/* Headline
===================================== */
#headline {
background-image: linear-gradient(90deg, var(--headline-bg-color-start), var(--headline-bg-color-end));
color: var(--headline-color);
transition: var(--theme-transition);
}
@media (max-width: 767.98px) {
#headline {
display: none;
}
}
.fbt-headline a {
color: var(--headline-color);
transition: var(--theme-transition);
}
.fbt-headline a:hover {
color: var(--headline-hover-color);
}
.fbt-headline .nav-link {
padding: .5rem .75rem!important;
line-height: 100%;
}
.fbt-headline li:first-child a,
.fbt-headline li:first-child .nav-link {
padding-left: 0!important;
}
.fbt-headline li:last-child a,
.fbt-headline li:last-child .nav-link {
padding-right: 0!important;
}
.fbt-headline .fbt-left-headline a,
.fbt-headline .fbt-left-headline .nav-link {
padding: .65rem .3rem!important;
line-height: normal;
text-transform: uppercase;
font-size: calc(14px - 1px);
}
.fbt-left-headline li:not(:first-child) a:before,
.fbt-left-headline li:not(:first-child) .nav-link:before {
content: '';
height: 5px;
width: 5px;
background-color: var(--color-1);
margin: 0 .6rem 3px 0;
display: inline-block;
vertical-align: middle;
border-radius: 2000px;
}
.fbt-headline .fbt-left-headline .LinkList ul {
display: -ms-flexbox;
display: flex;
-ms-flex-wrap: wrap;
flex-wrap: wrap;
padding-left: 0;
margin-bottom: 0;
list-style: none;
}
@media (max-width: 767.99px) {
.fbt-headline .fbt-left-headline .LinkList ul {
-ms-flex-pack: center!important;
justify-content: center!important;
}
}
/* Posts
===================================== */
.fbt-index-post .fbt-post-caption {
display: grid;
grid-gap: 14px;
}
.tooltip,
.feed-view .card-text,
.item-view .card-text,
.feed-view .blog-post {
font: var(--index-text-font);
}
.item-view .post-body {
font: var(--item-text-font)!important;
line-height: 1.75!important;
color: var(--post-text-color)!important;
}
.item-view .post-body a {
font-weight: bold;
text-decoration: underline;
}
.item-view .post-body h1,
.item-view .post-body h2,
.item-view .post-body h3,
.item-view .post-body h4,
.item-view .post-body h5,
.item-view .post-body h6 {
margin-bottom: 20px;
}
.item-view .post-body > ul {
margin-bottom: 25px;
}
.item-view .post-body .tr-caption {
font-size: 12px;
margin: 0;
padding-top: 5px;
color: var(--black);
}
.post-meta {
font: var(--meta-text-font);
color: var(--meta-text-color);
}
.post-meta > span:not(:last-child):after {
content: '\2014';
margin: 0 7px 0 9px;
font-weight: normal;
}
.post-meta, .post-meta a, .post-meta .post-author {
color: var(--meta-text-color);
}
.post-meta .post-author .author-avatar {
border-radius: 2000px;
margin-right: 7px;
margin-top: -3px;
}
.post-meta .post-date {
font-weight: normal;
text-transform: uppercase;
}
.post-meta a:hover {
color: var(--main-color);
}
.post-excerpt {
margin-bottom: 0;
}
.fbt-post-thumbnail {
width: 100%;
overflow: hidden;
position: relative;
padding-top: 65%;
}
@media (min-width: 1200px) {
.thumbnail-container {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
}
.caption-container {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
}
}
@media (max-width: 767.98px) {
.thumbnail-container {
margin-bottom: 20px;
}
.caption-container .post-excerpt {
display: block;
}
}
.item-view .fbt-post-thumbnail {
width: 100%;
height: auto;
}
.fbt-item-post .post-body img {
max-width: 100%;
height: auto;
}
.post-thumbnail {
width: 100%;
height: 100%;
object-fit: cover;
object-position: center;
}
.post-thumbnail:not(.ft-img) {
transform: scale(1.05) translateX(0);
transition: transform .4s ease-out, -webkit-transform .4s ease-out;
}
.post-thumbnail:not(.ft-img):hover {
transform: scale(1.05) translateX(-5px);
}
.fbt-post-thumbnail .post-thumbnail {
position: absolute;
top: 0;
left: 0;
right: 0;
bottom: 0;
}
.query-error .search-label,
.query-success .search-label,
.query-error .search-query,
.query-success .search-query {
color: var(--main-color);
}
.post-pager a:hover .fbt-np-title {
text-decoration: underline;
}
@media screen and (max-width: 575.98px){
body.item-view .post-body a[imageanchor="1"][style*="float: left;"],body.item-view .post-body a[imageanchor="1"][style*="float: right;"]{
float:none!important;
clear:none!important
}
body.item-view .post-body a[imageanchor="1"] img{
display:block;
height:auto;
margin:0 auto
}
body.item-view .post-body>.separator:first-child>a[imageanchor="1"]:first-child{
margin-top:20px
}
.post-body a[imageanchor]{
display:block
}
body.item-view .post-body a[imageanchor="1"]{
margin-left:0!important;
margin-right:0!important
}
body.item-view .post-body a[imageanchor="1"]+a[imageanchor="1"]{
margin-top:16px
}
}
.video-icon {
position: absolute;
top: 15px;
left: 15px;
width: 42px;
height: 42px;
text-align: center;
border-radius: 100%;
transition: all .2s ease-in-out;
color: #ffffff;
border: 2px solid #fff;
font-size: 18px;
background: rgba(0,0,0,0.2);
}
.video-icon i {
text-align: center;
margin-left: 3px;
line-height: 38px;
}
.single-pp-post-wrapper {
margin-top: 50px;
}
.page-view .fbt-item-post {
display: grid;
grid-gap: 40px;
}
.featuredImageContainer,
.featuredImageContainer .fbt-item-thumbnail-single {
margin-bottom: 40px;
}
.featuredImageContainer .fbt-item-caption {
display: -ms-grid;
display: grid;
grid-gap: 25px;
}
.page-view .post-title,
.featuredImageContainer .fbt-item-caption .post-title {
font-size: 3rem;
}
.fbt-index-post-wrap {
display: -ms-grid;
display: grid;
grid-template-columns: repeat(2, 1fr);
grid-column-gap: var(--grid-gap);
grid-row-gap: calc(var(--grid-gap) + 10px);
}
@media (max-width: 991.98px) {
.fbt-index-post-wrap {
display: -ms-grid;
display: grid;
grid-template-columns: 1fr;
}
}
.fbt-index-post-wrap .fbt-index-post .fbt-post-caption .post-title {
display: inline;
margin-right: .1rem;
}
.fbt-index-post-wrap .fbt-index-post .fbt-post-caption .post-excerpt {
font-weight: 300;
opacity: .8;
display: inline;
}
.fbt-index-post-wrap .caption-container {
margin-top: 20px;
padding-left: 20px;
}
.fbt-index-post-wrap .post-meta .index-post-tag {
color: var(--color-3);
text-transform: uppercase;
font-size: 14px;
}
.post-footer .p-tags .b-tags {
position: relative;
padding-top: 30px;
padding-bottom: 30px;
margin-top: 30px;
border-bottom: 2px dashed var(--border-color);
font: var(--h6-font);
font-weight: normal;
}
.post-footer .p-tags .b-tags::before {
position: absolute;
top: 0;
left: 0;
content: '';
width: 50px;
height: 3px;
background: var(--color-4);
z-index: 1;
}
.post-footer .p-tags .b-tags a {
font: var(--h6-font);
display: inline-block;
position: relative;
}
.post-footer .p-tags .b-tags a:not(:last-child)::after {
content: ',';
}
.post-footer .p-share .sharepost {
padding-top: 15px;
padding-bottom: 15px;
border-bottom: 2px dashed var(--border-color);
display: -webkit-box;
display: -ms-flexbox;
display: flex;
-webkit-box-align: center;
-ms-flex-align: center;
align-items: center;
}
.post-footer .p-share .sharepost .share-msg {
font: var(--h6-font);
}
.post-footer .p-share .sharepost .post-share {
margin-left: auto;
width: auto;
}
.post-footer .fbt-item-post-pager {
padding: 2rem 0;
border-bottom: 2px dashed var(--border-color);
}
.post-footer .fbt-item-post-pager .fbt-np-title {
margin-top: 10px;
}
@media (max-width: 767.98px) {
.post-footer .fbt-item-post-pager .previous {
margin-bottom: 2rem;
padding-bottom: 2rem;
border-bottom: 2px dashed var(--border-color);
}
}
.post-footer .about-author {
padding: 2rem 0;
border-bottom: 2px dashed var(--border-color);
}
.post-footer .about-author .avatar-container {
overflow: hidden;
border-radius: 2000px;
}
.post-footer .about-author .author-description {
font: var(--index-text-font);
line-height: 1.6;
}
/* Buttons
===================================== */
.load-more-posts {
margin-top: calc(var(--grid-gap) + 20px);
text-align: center;
}
@media (max-width: 991.98px) {
.load-more-posts {
margin-top: var(--grid-gap);
}
}
.query-btn,
.error-btn,
.load-more-posts .no-more-posts,
.load-more-posts .load-more {
display: inline-block;
padding: 1rem 30px;
min-width: 300px;
max-height: 49px;
background: var(--color-4);
color: var(--white);
cursor: pointer;
text-transform: uppercase;
font-weight: bold;
font-size: 14px;
border-radius: var(--block-radius);
}
.query-btn-small {
display: inline-block;
padding: .5rem 20px;
background: var(--color-4);
color: var(--white);
cursor: pointer;
text-transform: uppercase;
font-weight: bold;
font-size: 11px;
border-radius: var(--block-radius);
}
/* Share Buttons
===================================== */
.post-share {
float: left;
width: 100%;
margin: 0;
}
.post-share li {
margin: 0 2px 0 0;
display: inline-block;
-webkit-border-radius: 2px;
-moz-border-radius: 2px;
-o-border-radius: 2px;
border-radius: 2px;
}
.post-share li a {
position: relative;
margin: 0 0 0 1px;
font-weight: 700;
text-align: center;
vertical-align: middle;
color: #fff;
font-size: 15px;
display: inline-block;
-webkit-border-radius: 2px;
-moz-border-radius: 2px;
-o-border-radius: 2px;
border-radius: 2px;
transition: all 0.3s ease-in-out;
-moz-transition: all 0.3s ease-in-out;
-webkit-transition: all 0.3s ease-in-out;
-o-transition: all 0.3s ease-in-out;
}
.post-share .fa {
font-size: 16px;
position: relative;
height: 32px;
width: 32px;
line-height: 32px;
}
.post-share .fa.svg-share-icon {
line-height: 29px;
}
.post-share .fbt-svg-i {
width: 14px;
height: 14px;
}
.post-share ul {
list-style: none;
margin: 0;
padding: 0;
}
a.facebook.fbt-share {
background-color: #516eab;
}
a.twitter.fbt-share {
background-color: #29c5f6;
}
a.whatsapp.fbt-whatsapp {
background-color: #25D366;
}
a.linkedin.fbt-linkedin {
background-color: #0077b5;
}
a.pinterest.fbt-pinterest {
background-color: #ca212a;
}
.post-share .email.fbt-email {
background-color: #676869;
}
.post-share li a:hover {
color: #fff;
opacity: .8;
}
/* Back to Top
===================================== */
#BackToTop {
z-index: 9999;
position: fixed;
bottom: 0px;
right: 15px;
overflow: hidden;
display: none;
background: var(--color-4);
color: var(--white);
width: 40px;
height: 40px;
line-height: 37px;
text-align: center;
font-size: 22px;
cursor: pointer;
border-radius: var(--block-radius);
-webkit-transition: all .2s ease-out;
transition: all .2s ease-out;
}
#BackToTop:hover {
background: var(--color-5);
}
/* Comments
===================================== */
.blog-post-comments {
margin-top: 50px;
padding: 50px;
background: var(--comments-bg-color);
border-radius: var(--block-radius);
transition: var(--theme-transition);
}
.blog-post-comments .comments-content {
margin-top: 25px;
}
.blog-post-comments .footer .comment-form {
margin-top: 25px;
}
#comments .comment .comment-actions,
.widget.Profile .profile-link {
background: 0 0;
border: 0;
box-shadow: none;
cursor: pointer;
font-weight: 700;
outline: 0;
text-decoration: none;
text-transform: uppercase;
width: auto;
}
.item-control {
display: none;
}
#comments .comment-thread ol {
margin: 0;
padding-right: 0;
padding-left: 0;
}
#comments .comment .comment-replybox-single,
#comments .comment-thread .comment-replies {
margin-left: 60px;
margin-top: 35px;
}
#comments .comment-thread .thread-count {
display: none;
}
#comments .comment {
list-style-type: none;
position: relative;
margin-bottom: 35px;
}
#comments .comment .comment {
padding-bottom: 0;
}
.comment .avatar-image-container {
position: absolute;
}
.comment .avatar-image-container img {
border-radius: 50%;
}
.comment .comment-block {
margin-top: 0px;
margin-left: 50px;
padding-bottom: 0;
}
#comments .comment-author-header-wrapper {
margin-left: 40px;
}
#comments .comment .comment-actions {
top: 0;
right: 0;
position: absolute;
}
#comments .comment .comment-actions>* {
margin-left: 10px;
}
#comments .comment .comment-header .datetime {
bottom: 0;
display: inline-block;
font-size: 13px;
margin-left: 8px;
}
#comments .comment .comment-content,
.comment .comment-body {
margin-top: 12px;
word-break: break-word;
}
.comment-body {
margin-bottom: 12px;
}
#comments.embed[data-num-comments="0"] {
border: 0;
margin-top: 0;
padding-top: 0;
}
#comments.embed[data-num-comments="0"] #comment-post-message,
#comments.embed[data-num-comments="0"] div.comment-form>p,
#comments.embed[data-num-comments="0"] p.comment-footer {
display: none;
}
#comment-editor-src {
display: none;
}
#comments .comments-content .loadmore.loaded {
max-height: 0;
opacity: 0;
overflow: hidden;
}
#comments a,
#comments cite,
#comments div {
font-size: calc(14px + 1px);
line-height: 1.4;
}
#comments .comment .comment-header .user,
#comments .comment .comment-header .user a {
color: var(--title-color);
font: var(--h6-font);
}
#comments .comment .comment-header .user {
margin-right: 2px;
}
#comments .comment .comment-header .datetime a {
color: var(--black);
font: var(--index-text-font);
}
#comments .comment .comment-content {
margin-top: 15px;
margin-bottom: 15px;
background: var(--white);
color: var(--post-text-color);
padding: 25px 30px;
border-radius: 20px;
transition: var(--theme-transition);
}
[data-theme='dark'] #comments .comment .comment-content {
background: var(--dark);
}
#comments .continue {
display: none;
}
#comments p,
#comments .comment-footer {
margin: 0;
}
.comment-actions a {
color: var(--color-4);
font-size: 12px!important;
}
.comment-actions .item-control a {
color: var(--color-5);
}
.cmt_iframe_holder{
margin-left: 140px!important;
}
body.item-view .cmt_iframe_holder{
margin: 32px 24px!important;
}
@media (max-width: 991.98px) {
.blog-post-comments {
padding: 30px;
}
.comment .avatar-image-container {
position: relative;
}
.comment-header {
position: absolute;
top: 0;
left: 50px;
display: grid;
}
#comments .comment .comment-header .datetime {
margin-left: 0;
}
.comment .comment-block {
margin-left: 0;
}
#comments .comment .comment-replybox-single,
#comments .comment-thread .comment-replies {
margin-left: 30px;
}
}
/* Footer
===================================== */
#footer-content {
position: relative;
}
.fbt-footer-block .fbt-sep-title {
margin-bottom: 20px;
}
.fbt-footer-block .fbt-sep-title h4.title-heading-left {
color: var(--footer-widget-title-color);
font: var(--footer-widget-title-font);
height: auto;
line-height: 1.2em;
padding: 0;
border: 0;
background-color: transparent;
}
.fbt-footer-block .post-title,
.fbt-footer-block a {
color: var(--footer-widget-title-color);
}
.fbt-footer-block .post-title a:hover {
color: var(--footer-hover-text-color);
}
.fbt-footer-block .fbt-sep-title h4.title-heading-left:after {
border: 0;
}
.fbt-footer-block .fbt-sep-title .title-sep-container,
.fbt-footer-block .fbt-sep-title .title-sep.sep-double {
height: auto;
}
.fbt-footer-block .fbt-sep-title .title-sep {
border: 0;
background-color: transparent;
background-image: none;
}
.fbt-footer-block {
background-color: var(--footer-bg-color);
color: var(--footer-text-color);
margin-top: 50px;
transition: var(--theme-transition);
}
@media (max-width: 991.98px) {
.fbt-footer-block {
margin-top: calc(50px - 20px);
}
}
.fbt-footer-block .divider.top {
padding-bottom: 50px!important;
}
.fbt-footer-block .container.pb-4 {
padding-bottom: 45px!important;
}
.fbt-footer-block p {
color: var(--footer-text-color);
line-height: 1.65;
margin-bottom: 0;
}
.fbt-footer-block .nav-link {
color: var(--footer-text-color);
}
.fbt-footer-block .nav-link:hover {
color: var(--footer-hover-text-color);
}
.fbt-footer-block .list-unstyled {
margin-bottom: 0;
}
.fbt-footer-block .list-unstyled li a {
color: var(--footer-text-color);
}
.fbt-footer-block .list-unstyled li a:hover {
color: var(--footer-hover-text-color);
text-decoration: none;
}
#footer-right-big .widget {
margin-bottom: 3rem!important;
}
#footer-right-big .widget p {
margin-bottom: 25px;
}
[data-theme='dark'] .footer-1 #Image2 img {
-webkit-filter: brightness(0) invert(1);
filter: brightness(0) invert(1);
}
/* Popular Posts
===================================== */
.PopularPosts .fbt-title-caption .post-title {
font: var(--h6-font);
margin-bottom: 0;
}
.PopularPosts article {
padding: 0px 0;
margin-bottom: 30px;
}
.PopularPosts .border-top {
border-width: 0!important;
}
.PopularPosts article:first-child {
padding-top: 0px;
}
.PopularPosts article:last-child {
margin-bottom: 0!important;
}
.PopularPosts .post-meta {
margin-top: 7px;
display: block;
}
.PopularPosts .pp-post-tag {
margin-bottom: 5px;
display: inline-block;
font-size: 12px;
}
/* Label Cloud
===================================== */
.fbt-label-cloud {
color: #fff;
background: var(--main-color);
padding: 4px 7px 4px;
margin-bottom: 3px;
display: inline-block;
border-radius: 3px;
}
/* Blogger Widgets
===================================== */
.sidebar .widget .card:before {
position: absolute;
content: '';
width: 100%;
height: 1.5px;
background: #fff;
top: -1px;
left: 0;
}
/* Archive */
#ArchiveList select {background: var(--light);border:2px solid #eee;cursor:pointer;padding:10px;width:100%;font-size: 14px;}
.BlogArchive #ArchiveList ul ul li {padding-left:1.2em;}
/* Profile */
.widget.Profile{border-top:0;margin:0;margin-left:38px;margin-top:24px;padding-right:0 }body.sidebar-visible .widget.Profile{margin-left:0 }.widget.Profile .individual{text-align:center }.widget.Profile .individual .default-avatar-wrapper .avatar-icon{margin:auto }.widget.Profile .team{margin-bottom:32px;margin-left:32px;margin-right:32px }.widget.Profile ul{list-style:none;padding:0 }.widget.Profile li{margin:10px 0;text-align:left }.widget.Profile .profile-img{border-radius:50%;float:none }.widget.Profile .profile-info{margin-bottom:12px }.profile-snippet-fade{background:-webkit-linear-gradient(right,#ffffff 0,#ffffff 20%,rgba(255, 255, 255, 0) 100%);background:linear-gradient(to left,#ffffff 0,#ffffff 20%,rgba(255, 255, 255, 0) 100%);height:1.7em;position:absolute;right:16px;top:11.7em;width:96px }.profile-snippet-fade::after{content:'\2026';float:right }.widget.Profile .profile-location{color:#000000;font-size:16px;margin:0;opacity:.74 }.widget.Profile .team-member .profile-link::after{clear:both;content:'';display:table }.widget.Profile .team-member .profile-name{word-break:break-word }.widget.Profile .profile-datablock .profile-link{color:var(--dark);font:var(--h5-font);font-size:24px;text-transform:none;word-break:break-word }.widget.Profile .profile-datablock .profile-link+div{margin-top:16px!important }.widget.Profile .profile-link{font:var(--h6-font);font-size:14px }.widget.Profile .profile-textblock{color:var(--dark);font-size:14px;line-height:24px;margin:0 18px;opacity:.74;overflow:hidden;position:relative;word-break:break-word;}
/* Wikipedia */
.sidebar-wrapper .wikipedia-search-results, .wikipedia-search-results-header {margin-bottom: .5rem;}#wikipedia-search-result-link {padding: 5px 0;}.sidebar-wrapper .wikipedia-search-results a { margin-left: 15px;}
/* Translate */
.goog-te-combo {width: 100%;padding: 10px;}
/* Attribution */
.svg-icon-24, .svg-icon-24-button {cursor: pointer;height: 16px;width: 16px;min-width: 16px;}
.Attribution{text-align:center}
.Attribution .blogger img,.Attribution .blogger svg{vertical-align:bottom;}
.Attribution .blogger img{margin-right:.5em;}
.Attribution div{line-height:16px;margin-top:.5em;}
.Attribution .copyright,.Attribution .image-attribution{margin-top:.5em;}
.sidebar-wrapper .Attribution a {}
/* PageList */
.PageList .nav-link {padding: .5rem .5rem;}
.footer-menu .PageList .nav-link {padding: 0 .75rem;}
.footer-menu .PageList .nav-item:last-child .nav-link {padding-right: 0;}
.footer-menu .PageList .nav-item:first-child .nav-link {padding-left: 0;}
.footer-menu .PageList ul {-ms-flex-pack: center !important;justify-content: center !important;margin-top: 1rem !important;}
@media (min-width: 992px) {
.footer-menu .PageList ul {-ms-flex-pack: end !important;justify-content: flex-end !important;margin-top: 0 !important;}
}
.sidebar-wrapper .LinkList ul.list-unstyled {
margin-bottom: 0;
}
.sidebar-wrapper .LinkList li {
font-weight: bold;
}
.sidebar-wrapper .LinkList .fa {
font-size: 17px;
width: 40px;
height: 40px;
line-height: 40px;
border: 1px solid var(--border-color);
border-radius: 2000px;
text-align: center;
margin-right: 10px;
}
/* Forms */
.BlogSearch form {
position: relative;
overflow: hidden;
}
.BlogSearch .form-control {
width: 100%!important;
height: calc(1.5em + 0.75rem + 6px);
font-size: 14px;
}
.BlogSearch form .btn {
position: absolute;
right: 0;
top: 0;
}
/* Ads */
.fbt-ad-title {
font-size: 10.2px;
text-transform: uppercase;
letter-spacing: .15em;
color: var(--black);
position: relative;
width: 100%;
display: inline-block;
}
.ContactForm .contact-form-button {
background: var(--color-4);
color: #ffffff;
border: 0!important;
border-radius: var(--block-radius)!important;
overflow: hidden!important;
padding-left: 1.75rem!important;
padding-right: 1.75rem!important;
padding-bottom: .5rem!important;
padding-top: .5rem!important;
min-width: 200px;
}
.ContactForm .contact-form-button:hover {
background: var(--color-5);
color: #ffffff;
}
.form-control {
border-color: var(--border-color);
transition: var(--theme-transition);
}
[data-theme='dark'] .form-control {
background-color: rgba(255,255,255,0.1);
color: var(--white);
}
[data-theme='dark'] .form-control::placeholder {
color: var(--white);
}
/* Nav Search
===================================== */
.nav__search-box {
width: 300px;
position: absolute;
right: 15px;
top: 100%;
padding: 15px 20px;
display: none;
-webkit-box-shadow: 0 10px 30px rgba(0, 0, 0, 0.09);
box-shadow: 0 10px 30px rgba(0, 0, 0, 0.09);
background: var(--dropdown-menu-bg);
z-index: 1030;
}
@media only screen and (max-width: 991.98px) {
.nav__search-box {
top: calc(100% + .5rem);
}
}
@media only screen and (max-width: 991.98px) {
.nav__search-box {
width: 100%;
right: 0;
}
}
/* Homepage top Popular Posts
===================================== */
.fbt-item-thumbnail {
overflow: hidden;
}
.top-pp-posts {
display: -ms-grid;
display: grid;
grid-template-columns: repeat(5, 1fr);
grid-gap: var(--grid-gap);
}
@media(min-width: 992px) {
.canvas.grid-4.pp-bg #PopularPosts1 .top-pp-posts {
background-image: linear-gradient(180deg, transparent, var(--white) 80%),radial-gradient(ellipse at top left, var(--color-3), transparent 50%),radial-gradient(ellipse at top right, var(--info), transparent 50%),radial-gradient(ellipse at center right, var(--warning), transparent 50%),radial-gradient(ellipse at center left, var(--primary), transparent 50%);
padding: var(--grid-gap) var(--grid-gap) 0;
border-radius: calc(var(--block-radius) + 10px) calc(var(--block-radius) + 10px) 0 0;
transition: var(--theme-transition);
}
[data-theme='dark'] .canvas.grid-4.pp-bg #PopularPosts1 .top-pp-posts {
background-image: none;
padding: 0;
border-radius: 0;
}
}
@media (min-width: 1200px) {
.single-pp-post-wrapper .top-pp-posts {
grid-template-columns: repeat(5, 1fr);
}
}
@media (max-width: 1199.98px) {
.top-pp-posts,
.single-pp-post-wrapper .top-pp-posts {
grid-template-columns: repeat(4, 1fr);
}
.top-pp-posts .post:last-child,
.single-pp-post-wrapper .top-pp-posts .post:last-child {
display: none;
}
}
@media (max-width: 991.98px) {
.single-pp-post-wrapper .top-pp-posts,
.top-pp-posts {
-ms-grid-columns: 1fr;
grid-template-columns: 1fr;
grid-row-gap: 40px;
}
}
.top-pp-posts article {
margin: 0;
counter-increment: fbt-counter;
}
.top-pp-posts article .fbt-item-thumbnail {
position: relative;
padding-top: 65%;
}
.canvas .top-pp-posts article:nth-child(odd) .fbt-item-thumbnail {
position: relative;
padding-top: 100%;
}
@media (max-width: 991.98px) {
.canvas .top-pp-posts article:nth-child(odd) .fbt-item-thumbnail {
padding-top: 65%;
}
}
.canvas .top-pp-posts article:nth-child(even) .fbt-item-thumbnail {
position: relative;
padding-top: 65%;
}
@media(min-width: 992px) {
.canvas.grid-4 .top-pp-posts article:nth-child(even) .fbt-item-thumbnail {
padding-top:100%;
}
}
@media (max-width: 991.98px) {
.canvas .top-pp-posts article:nth-child(even) .fbt-item-thumbnail {
padding-top: 65%;
}
}
.top-pp-posts article .fbt-item-thumbnail .post-thumbnail {
position: absolute;
top: 0;
left: 0;
}
.top-pp-posts .is-content {
display: -webkit-box;
display: -ms-flexbox;
display: flex;
-webkit-box-orient: horizontal;
-webkit-box-direction: normal;
-ms-flex-flow: row nowrap;
flex-flow: row nowrap;
-webkit-box-align: center;
-ms-flex-align: center;
align-items: center;
margin-top: 20px;
position: relative;
}
.top-pp-posts .is-content::before {
-ms-flex-negative: 0;
flex-shrink: 0;
content: counter(fbt-counter);
display: -webkit-inline-box;
display: -ms-inline-flexbox;
display: inline-flex;
-webkit-box-pack: center;
-ms-flex-pack: center;
justify-content: center;
-webkit-box-align: center;
-ms-flex-align: center;
align-items: center;
width: 32px;
height: 32px;
line-height: 1;
border-radius: 1000px;
font-size: 14px;
background: var(--color-3);
color: var(--white);
font-weight: bold;
}
.single-pp-post-wrapper .top-pp-posts .is-content::before {
display: none;
}
.top-pp-posts .fbt-title-caption {
display: -ms-grid;
display: grid;
grid-gap: 13px;
margin-left: 20px;
}
.top-pp-posts .fbt-title-caption .entry-title .fbt-post-title {
display: inline;
margin-right: .1rem;
}
.top-pp-posts .fbt-title-caption .post-excerpt {
font-weight: 300;
opacity: .8;
display: inline;
}
.top-pp-posts .post-meta {
margin: 0;
}
.top-pp-posts .post-meta .label-link {
display: none;
}
.top-pp-posts .post-meta .label-link:first-child {
display: block;
color: var(--color-3);
text-transform: uppercase;
}
.is-bordered {
padding: var(--grid-gap);
background: var(--color-5);
}
@media (max-width: 1199.98px) {
.is-bordered {
padding: 30px;
}
}
.top-pp-posts.is-bordered a .entry-title,
.top-pp-posts.is-bordered a .h5 {
color: var(--white);
}
.top-pp-posts.is-bordered a:hover .entry-title,
.top-pp-posts.is-bordered a:hover .h5 {
color: var(--color-3);
}
/* Featured Post
===================================== */
.FeaturedPost .is-fp-container {
display: -ms-grid;
display: grid;
-ms-grid-columns: 1fr 1fr;
grid-template-columns: 1fr 1.54fr;
grid-column-gap: var(--grid-gap);
grid-row-gap: calc(var(--grid-gap) - 2px);
}
@media (min-width: 992px) {
.canvas.grid-4.pp-bg .FeaturedPost .is-fp-container {
-ms-grid-columns: 1fr 1.5fr;
grid-template-columns: 1fr 1.5fr;
}
}
@media (max-width: 991.98px) {
.FeaturedPost .is-fp-container {
-ms-grid-columns: 1fr;
grid-template-columns: 1fr;
}
}
.FeaturedPost .is-fp-container .is-fp-content {
display: -ms-grid;
display: grid;
-ms-flex-line-pack: center;
align-content: center;
}
.FeaturedPost .fbt-post-thumbnail {
padding-top: 62%;
}
.FeaturedPost .fbt-fp-content .post-title {
font-size: 2.2rem;
display: inline;
margin-right: 0.1rem;
}
@media(max-width: 1199.98px) {
.FeaturedPost .fbt-fp-content .post-title {
font-size: 1.8rem;
}
}
@media(max-width: 767.98px) {
.FeaturedPost .fbt-fp-content .post-title {
font-size: 22px;
}
}
.FeaturedPost .fbt-fp-content .post-excerpt {
display: inline;
font-weight: 300;
opacity: .8;
}
.FeaturedPost .post-meta {
margin: 0;
}
.FeaturedPost .post-meta .label-link {
display: none;
}
.FeaturedPost .post-meta .label-link:first-child {
display: block;
color: var(--color-3);
text-transform: uppercase;
font-size: 15px;
}
/* Header Ads
===================================== */
.fbt-top-header-ad {
position: relative;
padding-top: 0;
-webkit-transition: all .6s;
transition: all .6s;
z-index: 1;
}
.fbt-top-header-ad .ad-image-iframe {
clip: rect(0, auto, auto, 0);
overflow: hidden;
position: absolute;
left: 0;
top: 0;
width: 100%;
height: 100%;
}
.fbt-top-header-ad .img-iframe {
position: fixed;
text-align: center;
width: 100%;
top: 0;
left: 0;
}
.fbt-top-header-ad .img-iframe img {
max-width: 100%;
height: auto;
}
/* Dark Mode Switcher
===================================== */
.header-right {
display: flex;
align-items: center;
}
.dark-mode-switcher {
margin-left: 27px;
}
@media (max-width: 991.98px) {
.dark-mode-switcher {
margin-left: 0;
}
}
.dark-mode-switcher.no-items {
margin-left: 0;
}
#theme-switcher {
background-color: var(--switcher-background);
border-radius: 50px;
display: flex;
align-items: center;
gap: .5rem;
cursor: pointer;
padding: .3rem;
position: relative;
transition: var(--theme-transition);
}
#theme-switcher::before {
content: '';
position: absolute;
width: 1.4rem;
height: 1.4rem;
background-color: var(--switcher-circle-background);
border-radius: 50px;
z-index: 0;
left: .12rem;
top: 50%;
transform: translateY(-50%);
transition: var(--theme-transition);
}
[data-theme='dark'] #theme-switcher::before {
left: auto;
right: .12rem;
}
#theme-switcher svg {
z-index: 1;
width: 16px;
height: 16px;
transition: var(--theme-transition);
}
#icon-sun {
fill: var(--sun-color);
stroke: var(--sun-color);
}
#icon-moon {
fill: var(--moon-color);
stroke: var(--moon-color);
}
/* Modern Style
===================================== */
@media (min-width: 1200px) {
.canvas-modern .fbt-main-wrapper {
flex: 0 0 70%;
max-width: 70%;
}
.canvas-modern .sidebar-wrapper {
flex: 0 0 30%;
max-width: 30%;
}
}
@media (min-width: 992px) {
.canvas-modern .fbt-main-wrapper {
flex: 0 0 66.666667%;
max-width: 66.666667%;
}
.canvas-modern .sidebar-wrapper {
flex: 0 0 33.333333%;
max-width: 33.333333%;
}
}
.canvas-modern header {
margin-bottom: var(--header-margin)!important;
}
@media (max-width: 991.98px) {
.canvas-modern header {
margin-bottom: calc(var(--header-margin) - 20px)!important;
}
}
.canvas-modern .fbt-index-post-wrap {
grid-template-columns: 1fr;
grid-row-gap: var(--grid-gap);
}
.canvas-modern .fbt-index-post {
background: var(--info);
border: 1px solid var(--border-color);
padding: var(--grid-gap);
border-radius: var(--block-radius);
transition: var(--theme-transition);
}
@media (max-width: 767.98px) {
.canvas-modern .fbt-index-post {
padding: calc(var(--grid-gap) - 10px);
}
}
.canvas-modern .fbt-index-post:nth-child(1) {
background: var(--primary);
}
.canvas-modern .fbt-index-post:nth-child(2n+2) {
background: var(--warning);
}
.canvas-modern .fbt-index-post:nth-child(5n+5) {
background: var(--success);
}
[data-theme='dark'] .canvas-modern .fbt-index-post {
background: var(--dark);
}
.canvas-modern .bp-content {
display: -ms-grid;
display: grid;
-ms-grid-columns: 20% auto;
grid-template-columns: 20% auto;
grid-gap: var(--grid-gap);
}
@media (max-width: 1199.98px) and (min-width: 768px) {
.canvas-modern .bp-content {
-ms-grid-columns: 30% auto;
grid-template-columns: 30% auto;
}
}
@media (max-width: 767.98px) and (min-width: 576px) {
.canvas-modern .bp-content {
-ms-grid-columns: 40% auto;
grid-template-columns: 40% auto;
grid-column-gap: calc(var(--grid-gap) - 10px);
}
}
@media (max-width: 575.98px) {
.canvas-modern .bp-content {
-ms-grid-columns: 1fr;
grid-template-columns: 1fr;
grid-row-gap: calc(var(--grid-gap) - 20px);
}
.canvas-modern .bp-content .thumbnail-container {
margin: 0;
}
}
.canvas-modern .fbt-index-post-wrap .caption-container {
margin: 0;
padding: 0;
display: grid;
align-content: center;
}
.canvas-modern .fbt-post-thumbnail {
padding-top: 100%;
border: 1px solid var(--border-color);
}
.canvas-modern .fbt-item-thumbnail {
border: 1px solid var(--border-color);
}
.canvas-modern .fbt-footer-block {
border-top: 1px solid var(--credits-divider-color);
}
.canvas-modern .divider:not(.top):before {
opacity: 1;
}
.canvas-modern .query-btn,
.canvas-modern .error-btn,
.canvas-modern .load-more-posts .no-more-posts,
.canvas-modern .load-more-posts .load-more {
background: var(--warning);
border: 1px solid var(--border-color);
color: var(--black);
max-height: 54px;
}
[data-theme='dark'] .canvas-modern .query-btn,
[data-theme='dark'] .canvas-modern .error-btn,
[data-theme='dark'] .canvas-modern .load-more-posts .no-more-posts,
[data-theme='dark'] .canvas-modern .load-more-posts .load-more {
background: var(--dark);
color: var(--black);
}
@media (min-width: 992px) {
.canvas-modern .top-pp-posts {
grid-template-columns: repeat(3, 1fr);
}
}
.canvas-modern .top-pp-posts .post {
background: var(--success);
border: 1px solid var(--border-color);
border-radius: var(--block-radius);
padding: var(--grid-gap) calc(var(--grid-gap) - 20px);
position: relative;
}
.canvas-modern .top-pp-posts .post:nth-child(2) {
background: var(--warning);
}
.canvas-modern .top-pp-posts .post:nth-child(3) {
background: var(--info);
}
.canvas-modern .top-pp-posts .post:last-child {
display: block !important;
}
[data-theme='dark'] .canvas-modern .top-pp-posts .post {
background: var(--dark);
}
.canvas-modern .top-pp-posts .post .is-content {
margin: 0;
}
.canvas-modern .top-pp-posts .post .is-content::before {
width: 40px;
height: 40px;
background: var(--white);
border: 1px solid var(--border-color);
color: var(--black);
}
[data-theme='dark'] .canvas-modern .top-pp-posts .post .is-content::before {
background: var(--dark);
}
@media (min-width: 567px) {
.canvas-modern .top-pp-posts .post .is-content::before {
position: absolute;
left: -40px;
}
}
.canvas-modern .top-pp-posts .post .fbt-item-thumbnail {
padding-top: 100%;
display: none;
}
@media (min-width: 992px) {
.canvas-modern .dark-skin:not(.sticky__nav.scrolling_nav) {
background-color: transparent;
margin-top: calc(var(--header-margin) - 20px);
border: 0;
}
.canvas-modern .dark-skin:not(.sticky__nav.scrolling_nav) .container {
background-color: var(--header-bg-color);
border-radius: calc(var(--block-radius) * 2.2);
padding-left: var(--grid-gap);
padding-right: var(--grid-gap);
border: 1px solid var(--border-color);
transition: var(--theme-transition);
}
}
.canvas-modern .dropdown .dropdown-menu:before,
.canvas-modern .blog-wtitle {
display: none;
}
@media (min-width: 992px) {
.canvas-modern .dropdown .dropdown-menu {
border: 1px solid var(--border-color);
border-radius: var(--block-radius);
padding: 1rem 0;
}
.canvas-modern .dropdown .dropdown-menu .dropdown-item {
position: relative;
padding: 0.49rem 1.4rem 0.47rem calc(1.4rem - 3px);
}
}
@media (min-width: 992px) {
.canvas-modern .nav__search-box {
border: 1px solid var(--border-color);
border-radius: var(--block-radius);
}
}
.canvas-modern #theme-switcher {
border: 1px solid var(--border-color);
}
.canvas-modern #BackToTop {
background: var(--white);
color: var(--black);
border: 1px solid var(--border-color);
}
[data-theme='dark'] .canvas-modern #BackToTop {
background: var(--dark);
}
.canvas-modern .blog-post-comments,
.canvas-modern #comments .comment .comment-content {
border: 1px solid var(--border-color);
}
.canvas-modern .FeaturedPost .is-fp-container {
-ms-grid-columns: 66.666667% auto;
grid-template-columns: 66.666667% auto;
grid-template-areas: 'fbt-img fbt-caption';
background: var(--secondary);
border: 1px solid var(--border-color);
padding: var(--grid-gap);
border-radius: var(--block-radius);
-webkit-transition: var(--theme-transition);
transition: var(--theme-transition);
}
@media (max-width: 991.98px) {
.canvas-modern .FeaturedPost .is-fp-container {
-ms-grid-columns: 1fr;
grid-template-columns: 1fr;
grid-template-areas: 'fbt-img' 'fbt-caption';
}
}
@media (max-width: 575.98px) {
.canvas-modern .FeaturedPost .is-fp-container {
padding: calc(var(--grid-gap) - 10px);
}
}
[data-theme='dark'] .canvas-modern .FeaturedPost .is-fp-container {
background: var(--dark);
}
.canvas-modern .FeaturedPost .is-fp-container .is-post-thumbnail {
-ms-grid-row: 1;
-ms-grid-column: 1;
grid-area: fbt-img;
}
.canvas-modern .FeaturedPost .is-fp-container .is-fp-content {
-ms-grid-row: 1;
-ms-grid-column: 2;
grid-area: fbt-caption;
}
.canvas-modern .FeaturedPost .is-fp-container .fbt-post-thumbnail {
padding-top: 60%;
}
@media (min-width: 1200px) {
.canvas-modern .sidebar-wrapper .sidebar-wrapper__content {
padding-left: 3rem!important;
}
}
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) {
background: var(--warning);
border: 1px solid var(--border-color);
border-radius: var(--block-radius);
-webkit-transition: var(--theme-transition);
transition: var(--theme-transition);
overflow: hidden;
}
[data-theme='dark'] .canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) {
background: var(--dark);
}
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .widget-content {
padding: 0 calc(var(--grid-gap) - 10px) calc(var(--grid-gap) - 10px);
-webkit-transition: var(--theme-transition);
transition: var(--theme-transition);
}
@media (max-width: 1199.98px) and (min-width: 992px) {
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .widget-content {
padding: 0 calc(var(--grid-gap) - 10px) calc(var(--grid-gap) - 10px);
}
}
@media (max-width: 575.98px) {
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .widget-content {
padding: 0 calc(var(--grid-gap) - 10px) calc(var(--grid-gap) - 10px);
}
}
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .fbt-sep-title {
display: block;
padding: 15px calc(var(--grid-gap) - 10px) 17px;
background: var(--border-color);
}
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .fbt-sep-title h4.title-heading-left {
color: var(--white);
background: transparent;
}
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .fbt-sep-title .title-sep-container,
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .fbt-sep-title .title-sep.sep-double,
.canvas-modern .sidebar-wrapper .widget:not(.fbt-ad-block) .fbt-sep-title h4.title-heading-left {
height: auto;
border: 0;
}
.canvas-modern .label-name .badge-success {
background-color: var(--secondary) !important;
color: var(--black);
border: 1px solid var(--border-color);
padding: 0.5rem 1rem 0.4rem !important;
border-radius: var(--grid-gap);
}
[data-theme='dark'] .canvas-modern .label-name .badge-success {
background-color: var(--dark) !important;
}
.canvas-modern .widget.Profile {
margin: 0;
background: var(--secondary) !important;
}
[data-theme='dark'] .canvas-modern .widget.Profile {
background: var(--dark) !important;
}
.canvas-modern .widget.Profile .widget-content {
padding-top: calc(var(--grid-gap) - 10px) !important;
}
.canvas-modern .widget.Profile .profile-data {
margin-bottom: 15px;
}
.canvas-modern .widget.Profile .profile-datablock {
display: block;
}
.canvas-modern .widget.Profile .profile-datablock .profile-link.g-profile {
color: var(--black);
}
.canvas-modern .widget.Profile .profile-link:not(.g-profile) {
background-color: var(--info);
border: 1px solid var(--border-color);
padding: 9px 25px 8px;
display: inline-block;
border-radius: var(--block-radius);
}
[data-theme='dark'] .canvas-modern .widget.Profile .profile-link:not(.g-profile) {
background-color: var(--dark);
}
.canvas-modern .widget.Profile .profile-textblock {
color: var(--black);
line-height: 1.6;
margin: 0;
opacity: 1;
}
.canvas-modern .widget.Profile .profile-info {
margin-bottom: 0;
}
.canvas-modern .widget.Profile .profile-img {
border: 1px solid var(--border-color);
}
.canvas-modern .featuredImageContainer {
display: -ms-grid;
display: grid;
-ms-grid-columns: 40% auto;
grid-template-columns: 40% auto;
grid-gap: var(--grid-gap);
background: var(--info);
border: 1px solid var(--border-color);
padding: var(--grid-gap);
border-radius: var(--block-radius);
-webkit-transition: var(--theme-transition);
transition: var(--theme-transition);
margin-top: 0;
}
@media (max-width: 767.98px) {
.canvas-modern .featuredImageContainer {
-ms-grid-columns: 1fr;
grid-template-columns: 1fr;
padding: calc(var(--grid-gap) - 10px);
}
}
[data-theme='dark'] .canvas-modern .featuredImageContainer {
background: var(--dark);
}
.canvas-modern .featuredImageContainer .fbt-item-thumbnail-single {
margin: 0;
position: relative;
padding-top: 100%;
border: 1px solid var(--border-color);
}
.canvas-modern .featuredImageContainer .fbt-item-thumbnail-single img {
position: absolute;
top: 0;
}
.canvas-modern .featuredImageContainer .fbt-item-caption .post-title {
display: -ms-grid;
display: grid;
-ms-flex-line-pack: end;
align-content: end;
font-size: 2.2rem!important;
}
@media (max-width: 1199.98px) {
.canvas-modern .featuredImageContainer .fbt-item-caption .post-title {
font-size: 1.8rem !important;
}
}
@media (max-width: 767.98px) {
.canvas-modern .featuredImageContainer .fbt-item-caption .post-title {
font-size: 1.4rem !important;
}
}
.canvas-modern .post-footer .about-author .avatar-container,
.canvas-modern .post-meta .post-author .author-avatar {
border: 1px solid var(--border-color);
}
@media (max-width: 575.98px) {
.canvas-modern .post-meta .post-author .author-avatar {
display: none;
}
}
.canvas-modern.item-view .post-body {
background: var(--secondary);
border: 1px solid var(--border-color);
padding: var(--grid-gap);
border-radius: var(--block-radius);
-webkit-transition: var(--theme-transition);
transition: var(--theme-transition);
}
[data-theme='dark'] .canvas-modern.item-view .post-body {
background: var(--dark);
}
@media (max-width: 767.98px) {
.canvas-modern.item-view .post-body {
padding: calc(var(--grid-gap) - 10px);
}
}
.canvas-modern.item-view .post-footer {
background: var(--warning);
border: 1px solid var(--border-color);
padding: 10px var(--grid-gap) var(--grid-gap);
border-radius: var(--block-radius);
-webkit-transition: var(--theme-transition);
transition: var(--theme-transition);
margin-top: 40px;
}
[data-theme='dark'] .canvas-modern.item-view .post-footer {
background: var(--dark);
}
@media (max-width: 767.98px) {
.canvas-modern.item-view .post-footer {
padding: 0 calc(var(--grid-gap) - 10px) calc(var(--grid-gap) - 10px);
}
}
.canvas-modern .pp-post-wrapper .fbt-sep-title h4.title-heading-left,
.canvas-modern .blog-post-comments .fbt-sep-title h4.title-heading-left,
.canvas-modern .slider-container .fbt-sep-title h4.title-heading-left {
padding: 10px 20px;
border: 1px solid var(--left-side-border-color);
border-radius: var(--block-radius);
height: auto;
}
/* RTL
===================================== */
html[dir='rtl'] {
direction: rtl;
unicode-bidi: embed;
-webkit-locale: RTL;
text-align: right;
}
[dir='rtl'] div {direction:rtl;}
[dir='rtl'] p,
[dir='rtl'] ul, [dir='rtl'] ol, [dir='rtl'] dl {text-align: right!important;}
[dir='rtl'] .fbt-right-headline li:first-child a,
[dir='rtl'] .fbt-right-headline li:first-child .nav-link {
padding-left:0.75rem!important;
padding-right: 0!important;
}
[dir='rtl'] .fbt-right-headline li:last-child a,
[dir='rtl'] .fbt-right-headline li:last-child .nav-link {
padding-right: 0.75rem!important;
padding-left: 0!important;
}
[dir='rtl'] .fbt-left-headline li:not(:first-child) a:before,
[dir='rtl'] .fbt-left-headline li:not(:first-child) .nav-link:before {
margin: 0 0 3px 0.6rem;
}
[dir='rtl'] .fbt-headline .fbt-left-headline li:first-child a,
[dir='rtl'] .fbt-headline .fbt-left-headline li:first-child .nav-link {
padding-left: 0.3rem!important;
padding-right: 0!important;
}
[dir='rtl'] .fbt-headline .fbt-left-headline li:last-child a,
[dir='rtl'] .fbt-headline .fbt-left-headline li:last-child .nav-link {
padding-left: 0!important;
padding-right: 0.3rem!important;
}
@media (min-width: 992px) {
[dir='rtl'] .header-buttons {
border-right: 1px solid var(--search-border-color);
border-left: 0;
padding-left: 0;
padding-right: 27px;
margin-left: 0;
margin-right: 27px;
}
}
[dir='rtl'] .nav__search-box {
right: auto;
left: 15px;
}
[dir='rtl'] .BlogSearch form .btn {
right: auto;
left: 0;
}
[dir='rtl'] .navbar-dark .navbar-nav .nav-item:last-child .nav-link {
padding-right: 1.2rem;
padding-left: 0;
}
[dir='rtl'] .dropdown .dropdown-menu:before {
left: auto; *calc(100% - 55px);
right: 40px;
}
[dir='rtl'] .dropdown .dropdown-menu .dropdown-item {
padding: 0.49rem calc(1.2rem - 3px) 0.47rem 1.2rem;
border-left: 0;
border-right: 3px solid transparent;
}
[dir='rtl'] .dropdown .dropdown-menu .dropdown-item:hover,
[dir='rtl'] .dropdown .dropdown-menu .dropdown-item:focus {
border-right: 3px solid var(--main-color);
}
[dir='rtl'] .dark-mode-switcher {
margin-right: 27px;
margin-left: 0;
}
@media (max-width: 991.98px) {
[dir='rtl'] .dark-mode-switcher {
margin-right: 0;
}
}
[dir='rtl'] #theme-switcher::before {
right: 0.12rem;
left: auto;
}
[data-theme='dark'][dir='rtl'] #theme-switcher::before {
left: 0.12rem;
right: auto;
}
[dir='rtl'] .dropdown-toggle::after {
margin-right: 4px;
margin-left: 0;
}
[dir='rtl'] .post-meta > span:not(:last-child):after {
margin: 0 9px 0 9px;
}
[dir='rtl'] .post-meta .post-author .author-avatar {
margin-right: 0;
margin-left: 9px;
}
[dir='rtl'] blockquote p:before {
left: auto;
right: -25px;
-webkit-transform: scale(-1, 1);
transform: scale(-1, -1);
}
[dir='rtl'] .post-footer .p-tags .b-tags::before {
left: auto;
right: 0;
}
[dir='rtl'] .bi-share-fill.share-icon {
-webkit-transform: scale(-1, 1);
transform: scale(-1, 1);
}
[dir='rtl'] .post-share {
float: left;
}
[dir='rtl'] .post-footer .p-share .sharepost .post-share {
margin-left: 0;
margin-right: auto;
}
[dir='rtl'] .post-share .fa {
text-align: center!important;
}
[dir='rtl'] .post-pager .fa {
-webkit-transform: scale(-1, 1);
transform: scale(-1, 1);
}
[dir='rtl'] .top-pp-posts .fbt-title-caption {
margin-left: 0;
margin-right: 20px;
}
[dir='rtl'] .fbt-index-post-wrap .caption-container {
padding-left: 0;
padding-right: 20px;
}
[dir='rtl'] .comment .comment-block {
margin-left: 0;
margin-right: 50px;
}
[dir='rtl'] #comments .comment .comment-actions {
left: 0;
right: auto;
}
[dir='rtl'] #comments .comment .comment-actions>* {
margin-right: 10px;
margin-left: 0;
}
[dir='rtl'] #comments .comment .comment-header .user {
margin-right: 0;
margin-left: 2px;
}
[dir='rtl'] #comments .comment .comment-header .datetime {
margin-left: 0;
margin-right: 8px;
}
[dir='rtl'] #comments a,
[dir='rtl'] #comments cite,
[dir='rtl'] #comments div {
font-size: calc(14px + 1px)!important;
line-height: 1.4;
}
[dir='rtl'] #comments .comment .comment-replybox-single,
[dir='rtl'] #comments .comment-thread .comment-replies {
margin-left: 0;
margin-right: 60px;
}
@media (max-width: 991.98px) {
[dir='rtl'] .blog-post-comments {
padding: 30px;
}
[dir='rtl'] .comment .avatar-image-container {
position: relative;
}
[dir='rtl'] .comment-header {
position: absolute;
top: 0;
right: 50px;
display: grid;
}
[dir='rtl'] #comments .comment .comment-header .datetime {
margin-right: 0;
}
[dir='rtl'] .comment .comment-block {
margin-right: 0;
}
[dir='rtl'] #comments .comment .comment-replybox-single,
[dir='rtl'] #comments .comment-thread .comment-replies {
margin-right: 30px;
}
}
[dir='rtl'] .footer-menu .PageList .nav-item:last-child .nav-link {
padding-right: .75rem;
padding-left: 0;
}
[dir='rtl'] .footer-menu .PageList .nav-item:first-child .nav-link {
padding-left: .75rem;
padding-right: 0;
}
[dir='rtl'] .error-btn,
[dir='rtl'] .load-more-posts .no-more-posts,
[dir='rtl'] .load-more-posts .load-more {
line-height: 1;
}
[dir='rtl'] .errorWrap .lead {
text-align: center!important;
}
@media (min-width: 992px) {
[dir='rtl'] .hero-message .hero-text {
text-align: center!important;
}
}
@media (min-width: 567px) {
[dir='rtl'] .canvas-modern .top-pp-posts .post .is-content::before {
right: -40px;
left: auto;
}
}
[dir='rtl'] .canvas-modern .top-pp-posts .post::after {
left: calc(-1px - var(--grid-gap));
right: auto;
}
[dir='rtl'] .canvas-modern .fbt-index-post-wrap .caption-container {
padding: 0;
}
@media (min-width: 1200px) {
[dir='rtl'] .canvas-modern .sidebar-wrapper .sidebar-wrapper__content {
padding-left: 0!important;
padding-right: 3rem!important;
}
}
[dir='rtl'] .sidebar-wrapper .LinkList .fa {
margin-right: 0;
margin-left: 10px;
}

--></style>
<style>
        .fbt-main-wrapper {-ms-flex: 0 0 100%;flex: 0 0 100%;max-width: 100%;}
        .sidebar-wrapper {display: none;}
        .fbt-index-post-wrap {
        	grid-template-columns: repeat(3, 1fr);
        }
        .canvas.grid-4 .fbt-index-post-wrap {
        	grid-template-columns: repeat(4, 1fr);
        }
        @media (max-width: 1199.98px) and (min-width: 992px) {
            .canvas.grid-4 .fbt-index-post-wrap,
            .fbt-index-post-wrap {
                display: -ms-grid;
                display: grid;
                grid-template-columns: repeat(3, 1fr);
            }
        }
        @media (max-width: 991.98px) {
            .canvas.grid-4 .fbt-index-post-wrap,
            .fbt-index-post-wrap {
                grid-template-columns: 1fr;
            }
        }
        @media (min-width: 992px) {
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) {
                -ms-grid-column: 1;
                -ms-grid-column-span: 3;
                grid-column: 1 / span 3;
                position: relative;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post .fbt-post-thumbnail {
        		padding-top: 100%;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .fbt-post-thumbnail {
            	padding-top: 45%;
            	position: relative;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container {
                position: absolute;
                bottom: 0;
                left: 0;
                margin: 0;
                padding: 40px;
                width: 100%;
                z-index: 1;
                background-image: -webkit-gradient(linear, left bottom, left top, color-stop(10%, rgba(0, 0, 0, 0.8)), to(rgba(0, 0, 0, 0)));
                background-image: linear-gradient(to top, rgba(0, 0, 0, 0.8) 10%, rgba(0, 0, 0, 0) 100%);
                border-radius: 0 0 var(--block-radius) var(--block-radius);
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption {
            	max-width: 700px;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption .post-meta .index-post-tag,
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption a,
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption a .post-title,
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption a .h3 {
            	color: var(--white) !important;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption .post-title {
            	font-size: 2.1rem;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption .post-excerpt {
            	font-size: 2.1rem;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(2) {
                -ms-grid-column: 1;
                -ms-grid-column-span: 2;
                grid-column: 1 / 3;
                -ms-grid-row: 2;
                grid-row: 2;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(2) .fbt-post-thumbnail {
            	padding-top: 65%;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(2) .fbt-post-caption .post-title {
            	font-size: 2.1rem;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(2) .fbt-post-caption .post-excerpt {
            	font-size: 2.1rem;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) {
            	height: 100%;
            	position: relative;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .bp-content {
            	height: 100%;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .bp-content .thumbnail-container {
            	height: 100%;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .bp-content .thumbnail-container .fbt-post-thumbnail {
            	padding-top: 0;
            	height: 100%;
            	position: relative;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .caption-container {
            	position: absolute;
            	bottom: 0;
            	left: 0;
            	margin: 0;
            	padding: 40px;
            	width: 100%;
            	z-index: 1;
            	background-image: -webkit-gradient(linear, left bottom, left top, color-stop(10%, rgba(0, 0, 0, 0.8)), to(rgba(0, 0, 0, 0)));
            	background-image: linear-gradient(to top, rgba(0, 0, 0, 0.8) 10%, rgba(0, 0, 0, 0) 100%);
            	border-radius: 0 0 var(--block-radius) var(--block-radius);
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .caption-container .fbt-post-caption .post-meta .index-post-tag,
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .caption-container .fbt-post-caption a,
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .caption-container .fbt-post-caption a .post-title,
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(3) .caption-container .fbt-post-caption a .h3 {
            	color: var(--white) !important;
            }
        }
        @media (max-width: 1199.98px) and (min-width: 992px) {
            .canvas.grid-4 .fbt-index-post-wrap .fbt-index-post:nth-child(1) {
                -ms-grid-column: 1;
                -ms-grid-column-span: 3;
                grid-column: 1 / span 3;
                position: relative;
            }
        }
        @media (min-width: 1200px) {
            .canvas.grid-4 .fbt-index-post-wrap .fbt-index-post:nth-child(1) {
                -ms-grid-column: 1;
                -ms-grid-column-span: 4;
                grid-column: 1 / span 4;
                position: relative;
            }
            .canvas.grid-4 .fbt-index-post-wrap .fbt-index-post:nth-child(2) {
                -ms-grid-column: 1;
                -ms-grid-column-span: 2;
                grid-column: 1 / 3;
                -ms-grid-row: 2;
                grid-row: 2;
            }
            .canvas.grid-4 .fbt-index-post-wrap .fbt-index-post:nth-child(3) .caption-container {
            	padding: 30px;
            }
            .canvas.grid-4 .fbt-index-post-wrap .fbt-index-post:nth-child(4) .fbt-post-thumbnail {
            	padding-top: 135%;
            }
        }
        @media (max-width: 1199.98px) and (min-width: 992px) {
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption .post-title {
            	font-size: 2rem;
            }
            .canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .caption-container .fbt-post-caption .post-excerpt {
            	font-size: 2rem;
            }
        }
        .slebew {
    display: flex;
    flex-direction: row;
  }

  .slebew div {
    width: 130px;
    height: 100px;
    background-color: lightblue;
    margin: 5px;
    border-radius: 10px; /* Sesuaikan nilai radius sesuai kebutuhan */
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid black;
  }
      </style>
<!-- Google Analytics -->

</head>
<body class='home feed-view canvas-modern mauro-theme version-1.1.1'>
<!-- Theme Options -->
<div class='options-sidebar d-none'>
    <div class='mauro-options section' id='mauro-options' name='Mauro Options'><div class='widget Header' data-version='2' id='Header2'>
    <div class='header-widget'>
    <a class='header-image-wrapper clearfix' href='/'>
    <img alt='albar' data-height='34' data-width='220' src='img/albar.png'/>
    </a>
    </div>
    </div><div class='widget ContactForm' data-version='2' id='ContactForm1'>
    <div class='fbt-sep-title'>
    <h4 class='title title-heading-left'>
    Contact Form
    </h4>
    <div class='title-sep-container'><div class='title-sep sep-double'></div></div>
    </div>
    <div class='contact-form-widget'>
    <div class='form'>
    <form name='contact-form form-inline'>
    <p></p>
    Name
    <br/>
    <input class='contact-form-name form-control mt-1 radius-0 shadow-none' id='ContactForm1_contact-form-name' name='name' size='30' type='text' value=''/>
    <p></p>
    Email
    <span style='font-weight: bolder;'>*</span>
    <br/>
    <input class='contact-form-email form-control mt-1 radius-0 shadow-none' id='ContactForm1_contact-form-email' name='email' size='30' type='text' value=''/>
    <p></p>
    Message
    <span style='font-weight: bolder;'>*</span>
    <br/>
    <textarea class='contact-form-email-message form-control mt-1 radius-0 shadow-none' cols='25' id='ContactForm1_contact-form-email-message' name='email-message' rows='5'></textarea>
    <p></p>
    <input class='contact-form-button contact-form-button-submit' id='ContactForm1_contact-form-submit' type='button' value='Send'/>
    <p></p>
    <div style='text-align: center;width: 100%'>
    <p class='contact-form-error-message' id='ContactForm1_contact-form-error-message'></p>
    <p class='contact-form-success-message' id='ContactForm1_contact-form-success-message'></p>
    </div>
    </form>
    </div>
    </div>
    </div></div>
    </div>
    <!--Page Wrapper -->
    <div id='page-wrapper'>
    <div class='fbt-top-header-ad'>
    <div class='ad-image-iframe'>
    <div class='img-iframe no-items section' id='fbt_header--banner' name='Header Banner'></div>
    </div>
    </div>
    <header>
    <div class='fbt-headline clearfix' id='headline'>
    <div class='container'>
    <div class='row align-items-center justify-content-between py-1 py-md-0'>
    <div class='col-md-7 left-headline-content'>
    <div class='fbt-left-headline no-items section' id='left-headline' name='Headline Left'>
    </div>
    </div>
    <div class='col-md-5 right-headline-content'>
    <div class='fbt-right-headline no-items section' id='right-headline' name='Headline Right'>
    </div>
    </div>
    </div>
    </div>
    </div>
    <nav class='navbar navbar-expand-lg navbar-dark dark-skin fbt_sticky_nav'>
    <div class='container position-relative clearfix'>
    <div class='navbar-brand order-2 order-lg-1 m-auto section' id='header-logo' name='Logo'><div class='widget Header' data-version='2' id='Header1'>
    <div class='header-widget'>
    <a class='header-image-wrapper clearfix' href='/'>
    <img alt='JOKI IN AJA'  data-width='220' src='img/albar.png'/>
    </a>
    </div>
    </div></div>
    <button aria-controls='navbar' aria-expanded='false' aria-label='Toggle navigation' class='navbar-toggler order-1 order-xl-2' data-target='#navbar' data-toggle='collapse' type='button'>
    <svg class='navbar-icon' height='30' viewBox='0 0 30 30' width='30' xmlns='http://www.w3.org/2000/svg'><path d='M4 7h22M4 15h22M4 23h22' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2'></path></svg>
    </button>
    <div class='header-right order-3 order-lg-4'>
    <div class='nav__search d-none d-lg-block'>
    <div class='fbt-search-trigger section' id='trigger' name='Search Button'><div class='widget HTML' data-version='2' id='HTML4'>
    <div class='html-widget-content header-buttons'>
    <span class='fa fa-search navbar-search search-trigger'></span>
    </div>
    </div></div>
    <div class='nav__search-box section' id='nav__search-box' name='Search Box'><div class='widget BlogSearch' data-version='2' id='BlogSearch111'>
    <div class='widget-content' role='search'>
    
    </div>
    </div></div>
    </div>
    <div class='dark-mode-switcher section' id='dark-mode-switcher' name='Switcher Button'><div class='widget HTML' data-version='2' id='HTML5'>
    <div class='html-widget-content'>
    <div id='theme-switcher'>
    <svg class='dm-icon icon-sun' height='24' id='icon-sun' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><circle cx='12' cy='12' r='5'></circle><line x1='12' x2='12' y1='1' y2='3'></line><line x1='12' x2='12' y1='21' y2='23'></line><line x1='4.22' x2='5.64' y1='4.22' y2='5.64'></line><line x1='18.36' x2='19.78' y1='18.36' y2='19.78'></line><line x1='1' x2='3' y1='12' y2='12'></line><line x1='21' x2='23' y1='12' y2='12'></line><line x1='4.22' x2='5.64' y1='19.78' y2='18.36'></line><line x1='18.36' x2='19.78' y1='5.64' y2='4.22'></line></svg>
    <svg class='dm-icon icon-moon' height='24' id='icon-moon' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z'></path></svg>
    </div>
    </div>
    </div></div>
    </div>
    <div class='collapse navbar-collapse order-4 order-lg-3 clearfix section' id='navbar' name='Main Menu'><div class='widget LinkList' data-version='2' id='LinkList1'>
    <div class='widget-content'>
    <ul>
    <li><a href='/'>Home</a></li>
    <li><a href='/CV'>Persyaratan membuat CV</a></li>
    <li><a href='/blog'>Poster</a></li>
    <li><a href='/login'>Admin</a></li>
    </ul>
    </div>
    </div></div>
<script> 
              //<![CDATA[
            $("#LinkList1").each(function() {
              var a = "<ul class='navbar-nav ml-auto clearfix'><li><ul class='dropdown-menu'>";
              $("#LinkList1 li").each(function() {
                var b = $(this).text(),
                    c = b.substr(0, 1),
                    d = b.substr(1);
                "_" === c ? (c = $(this).find("a").attr("href"), a += '<li><a href="' + c + '">' + d + "</a></li>") : (c = $(this).find("a").attr("href"), a += '</ul></li><li><a href="' + c + '">' + b + "</a><ul class='dropdown-menu'>")
              }), a += "</ul></li></ul>", $(this).html(a), $("#LinkList1 ul").each(function() {
                var a = $(this);
                0 === a.html().replace(/\s|&nbsp;/g, "").length && a.remove()
              }), $("#LinkList1 li").each(function() {
                var a = $(this);
                0 === a.html().replace(/\s|&nbsp;/g, "").length && a.remove()
              })
            });
            //]]>
            </script>
</div>
</nav>
</header>
<div class='clearfix'></div>
<div class='slider-container'>
<div class='slider-container-row section' id='slider-posts' name='Main Slider'><div class='widget FeaturedPost' data-version='2' id='FeaturedPost1'>
<div class='widget-content mb-4 mb-md-5 pb-4'>
<div class='FeaturedPostContainer'>
<div class='container'>
<div class='is-fp-container'>
<div class='is-fp-content'>
<div class='post-meta mb-3'>
</div>
<div class='fbt-fp-content'>
<h1 class='post-title'>
Maksimalkan CV mu disini!!
</h1>
<p class='post-excerpt post-title h1'>JOKI CV dan MENYUSUN LAMARAN dengan cepat hanya di sini!!.</p>
</a>
</div>
</div>
<div class='is-post-thumbnail'>
<div class='fbt-post-thumbnail'>
<img alt='Image' class='post-thumbnail' sizes='100px' src='img/awalcv.jpg'/>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class='widget PopularPosts' data-version='2' id='PopularPosts1'>
<div class='container'>
</div>
<div class='widget-content mb-4 mb-md-5 pb-4'>
<div class='container'>
<div class='top-pp-posts'>
<!-- disini -->
<div class="slebew">
<div><strong>We Care</strong></div>
<div><strong>We Do</strong></div>
<div><strong>We Winner</strong></div>
</div>
   

</div>
</div>
</div>
</div>
</div>
</div>
<!-- Outer Wrapper -->
<div class='outer-wrapper clearfix' id='outer-wrapper'>
<div class='container'>
<div class='row justify-content-center'>
<!-- Main Wrapper -->
<div class='fbt-main-wrapper col-lg-8'>
<div id='main-wrapper'>
<div class='main section' id='main' name='Main Content'><div class='widget Blog' data-version='2' id='Blog1'>
<div class='fbt-sep-title blog-wtitle'>
<h4 class='title title-heading-left'>Recent posts</h4>
<div class='title-sep-container'><div class='title-sep sep-double'></div></div>
</div>
<div class='row justify-content-center'>
</div>
<div class='blog-posts hfeed fbt-index-post-wrap'>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='/CV'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV1_.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>

</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 1
</h3> <br>
<p class='post-excerpt h3'> design simple, elegan!</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>

<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV2.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>
</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 2
</h3> <br>
<p class='post-excerpt h3'>Cerah Gembira, Asri.</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='/CV'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV3_.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>
</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 3
</h3> <br>
<p class='post-excerpt h3'>Mewah Pool</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='/CV'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV4.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>

</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 4
</h3> <br>
<p class='post-excerpt h3'>Rapih Sopan.</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='/CV'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV5.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>

</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 5
</h3> <br>
<p class='post-excerpt h3'>Klasik, keren.</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='2017/03/nunc-accumsan-ex-ligula-in-sapien.html'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV6.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>
</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 6
</h3> <br>
<p class='post-excerpt h3'>Happy Rainbow</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='/CV'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV7.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>
</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 7
</h3> <br>
<p class='post-excerpt h3'>Dark, Menarik, Elegan</p>
</a>
</div>
</div>
</div>
</article>
<article class='blog-post hentry fbt-index-post'>
<div class='bp-content'>
<div class='thumbnail-container'>
<div class='fbt-post-thumbnail'>
<a href='/CV'>
<img alt='Image' class='post-thumbnail' sizes='1200px' src='img/CV8.jpg'/>
</a>
</div>
</div>
<div class='caption-container'>
<div class='fbt-post-caption'>
<div class='post-meta'>
<span class='post-tag index-post-tag'>

</span>
</div>
<a href='/CV'>
<h3 class='post-title'>
CV 8
</h3>
<p class='post-excerpt h3'>Simple, Perfect</p>
</a>
</div>
</div>
</div>
</article>
</div>

</div>
<script>var loadmore_txt = 'Load more posts';</script>
</div></div>
</div><!-- #main-wrapper -->
</div><!-- .fbt-main-wrapper -->
<!-- Sidebar Wrapper -->
<div class='sidebar-wrapper col-lg-4' id='sidebar-wrapper'>
<div class='sidebar-wrapper__content h-100 pl-xl-4'>
<div class='sidebar h-100 section' id='main_sidebar' name='Main Sidebar'><div class='widget LinkList' data-version='2' id='LinkList4'>
<div class='fbt-sep-title'>
<h4 class='title title-heading-left'>
Follow Us
</h4>
<div class='title-sep-container'><div class='title-sep sep-double'></div></div>
</div>
<div class='widget-content'>
<ul class='list-unstyled'>
    <li><a href='https://wa.me/qr/6KDKOMPIAOWOG1'><i class="fa fa-whatsapp"></i>085770727528 / klik logo disamping</a></li>
<li><a href='https://www.instagram.com/albarree/'><i class="fa fa-instagram"></i>@albarree</a></li>
<li><a href='https://www.instagram.com/warung_joki_karawang/'><i class="fa fa-instagram"></i>@warung_joki_karawang</a></li>
</ul>
</div>




</a>
<br/>
</div>
</div></div>
</div>
</div><!-- #sidebar-wrapper -->
</div>
</div>
</div>
<!-- Footer -->
<div class='fbt-footer-block pt-2 clearfix' id='footer-content'>
<div class='container'>
<div class='divider top'></div>
</div>
<div class='container pb-1'>
<div class='row clearfix'>
<div class='col-lg-4'>
<div class='footer-1 section' id='footer-1' name='Footer 1'><div class='widget Image' data-version='2' id='Image2'>
<div class='widget-content mb-n3'>

</div>
</div><div class='widget Text' data-version='2' id='Text1'>
<h2>MAKSIMALKAN CV MU DISINI!</h2></div>
</div></div>
</div>


</div><!-- #footer-content -->
<div id='BackToTop'>
<i class='fa fa-angle-up'></i>
</div><!-- back-to-top -->
</div><!-- #page-wrapper -->
<script async='async' src='../../cdn.jsdelivr.net/npm/bootstrap%404.6.2/dist/js/bootstrap.bundle.min83b6.js?ver=4.6.2'></script>
<script>
      //<![CDATA[
   /*! modernizr 3.6.0 (Custom Build) | MIT */
    !function(e,n,t){function r(e,n){return typeof e===n}function o(){var e,n,t,o,i,s,a;for(var l in C)if(C.hasOwnProperty(l)){if(e=[],n=C[l],n.name&&(e.push(n.name.toLowerCase()),n.options&&n.options.aliases&&n.options.aliases.length))for(t=0;t<n.options.aliases.length;t++)e.push(n.options.aliases[t].toLowerCase());for(o=r(n.fn,"function")?n.fn():n.fn,i=0;i<e.length;i++)s=e[i],a=s.split("."),1===a.length?Modernizr[a[0]]=o:(!Modernizr[a[0]]||Modernizr[a[0]]instanceof Boolean||(Modernizr[a[0]]=new Boolean(Modernizr[a[0]])),Modernizr[a[0]][a[1]]=o),g.push((o?"":"no-")+a.join("-"))}}function i(e){var n=_.className,t=Modernizr._config.classPrefix||"";if(w&&(n=n.baseVal),Modernizr._config.enableJSClass){var r=new RegExp("(^|\\s)"+t+"no-js(\\s|$)");n=n.replace(r,"$1"+t+"js$2")}Modernizr._config.enableClasses&&(n+=" "+t+e.join(" "+t),w?_.className.baseVal=n:_.className=n)}function s(e){return e.replace(/([a-z])-([a-z])/g,function(e,n,t){return n+t.toUpperCase()}).replace(/^-/,"")}function a(){return"function"!=typeof n.createElement?n.createElement(arguments[0]):w?n.createElementNS.call(n,"http://www.w3.org/2000/svg",arguments[0]):n.createElement.apply(n,arguments)}function l(){var e=n.body;return e||(e=a(w?"svg":"body"),e.fake=!0),e}function u(e,t,r,o){var i,s,u,f,d="modernizr",c=a("div"),p=l();if(parseInt(r,10))for(;r--;)u=a("div"),u.id=o?o[r]:d+(r+1),c.appendChild(u);return i=a("style"),i.type="text/css",i.id="s"+d,(p.fake?p:c).appendChild(i),p.appendChild(c),i.styleSheet?i.styleSheet.cssText=e:i.appendChild(n.createTextNode(e)),c.id=d,p.fake&&(p.style.background="",p.style.overflow="hidden",f=_.style.overflow,_.style.overflow="hidden",_.appendChild(p)),s=t(c,e),p.fake?(p.parentNode.removeChild(p),_.style.overflow=f,_.offsetHeight):c.parentNode.removeChild(c),!!s}function f(e,n){return!!~(""+e).indexOf(n)}function d(e,n){return function(){return e.apply(n,arguments)}}function c(e,n,t){var o;for(var i in e)if(e[i]in n)return t===!1?e[i]:(o=n[e[i]],r(o,"function")?d(o,t||n):o);return!1}function p(e){return e.replace(/([A-Z])/g,function(e,n){return"-"+n.toLowerCase()}).replace(/^ms-/,"-ms-")}function m(n,t,r){var o;if("getComputedStyle"in e){o=getComputedStyle.call(e,n,t);var i=e.console;if(null!==o)r&&(o=o.getPropertyValue(r));else if(i){var s=i.error?"error":"log";i[s].call(i,"getComputedStyle returning null, its possible modernizr test results are inaccurate")}}else o=!t&&n.currentStyle&&n.currentStyle[r];return o}function v(n,r){var o=n.length;if("CSS"in e&&"supports"in e.CSS){for(;o--;)if(e.CSS.supports(p(n[o]),r))return!0;return!1}if("CSSSupportsRule"in e){for(var i=[];o--;)i.push("("+p(n[o])+":"+r+")");return i=i.join(" or "),u("@supports ("+i+") { #modernizr { position: absolute; } }",function(e){return"absolute"==m(e,null,"position")})}return t}function y(e,n,o,i){function l(){d&&(delete T.style,delete T.modElem)}if(i=r(i,"undefined")?!1:i,!r(o,"undefined")){var u=v(e,o);if(!r(u,"undefined"))return u}for(var d,c,p,m,y,h=["modernizr","tspan","samp"];!T.style&&h.length;)d=!0,T.modElem=a(h.shift()),T.style=T.modElem.style;for(p=e.length,c=0;p>c;c++)if(m=e[c],y=T.style[m],f(m,"-")&&(m=s(m)),T.style[m]!==t){if(i||r(o,"undefined"))return l(),"pfx"==n?m:!0;try{T.style[m]=o}catch(g){}if(T.style[m]!=y)return l(),"pfx"==n?m:!0}return l(),!1}function h(e,n,t,o,i){var s=e.charAt(0).toUpperCase()+e.slice(1),a=(e+" "+z.join(s+" ")+s).split(" ");return r(n,"string")||r(n,"undefined")?y(a,n,o,i):(a=(e+" "+P.join(s+" ")+s).split(" "),c(a,n,t))}var g=[],C=[],S={_version:"3.6.0",_config:{classPrefix:"",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(e,n){var t=this;setTimeout(function(){n(t[e])},0)},addTest:function(e,n,t){C.push({name:e,fn:n,options:t})},addAsyncTest:function(e){C.push({name:null,fn:e})}},Modernizr=function(){};Modernizr.prototype=S,Modernizr=new Modernizr;var _=n.documentElement,w="svg"===_.nodeName.toLowerCase(),x=function(){var n=e.matchMedia||e.msMatchMedia;return n?function(e){var t=n(e);return t&&t.matches||!1}:function(n){var t=!1;return u("@media "+n+" { #modernizr { position: absolute; } }",function(n){t="absolute"==(e.getComputedStyle?e.getComputedStyle(n,null):n.currentStyle).position}),t}}();S.mq=x,Modernizr.addTest("mediaqueries",x("only all"));var b="Moz O ms Webkit",z=S._config.usePrefixes?b.split(" "):[];S._cssomPrefixes=z;var E=function(n){var r,o=prefixes.length,i=e.CSSRule;if("undefined"==typeof i)return t;if(!n)return!1;if(n=n.replace(/^@/,""),r=n.replace(/-/g,"_").toUpperCase()+"_RULE",r in i)return"@"+n;for(var s=0;o>s;s++){var a=prefixes[s],l=a.toUpperCase()+"_"+r;if(l in i)return"@-"+a.toLowerCase()+"-"+n}return!1};S.atRule=E;var P=S._config.usePrefixes?b.toLowerCase().split(" "):[];S._domPrefixes=P;var N={elem:a("modernizr")};Modernizr._q.push(function(){delete N.elem});var T={style:N.elem.style};Modernizr._q.unshift(function(){delete T.style}),S.testAllProps=h;var j=S.prefixed=function(e,n,t){return 0===e.indexOf("@")?E(e):(-1!=e.indexOf("-")&&(e=s(e)),n?h(e,n,t):h(e,"pfx"))};Modernizr.addTest("matchmedia",!!j("matchMedia",e)),o(),i(g),delete S.addTest,delete S.addAsyncTest;for(var q=0;q<Modernizr._q.length;q++)Modernizr._q[q]();e.Modernizr=Modernizr}(window,document);
 /* jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/ */
    jQuery.easing.jswing=jQuery.easing.swing;jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(e,f,a,h,g){return jQuery.easing[jQuery.easing.def](e,f,a,h,g)},easeInQuad:function(e,f,a,h,g){return h*(f/=g)*f+a},easeOutQuad:function(e,f,a,h,g){return -h*(f/=g)*(f-2)+a},easeInOutQuad:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f+a}return -h/2*((--f)*(f-2)-1)+a},easeInCubic:function(e,f,a,h,g){return h*(f/=g)*f*f+a},easeOutCubic:function(e,f,a,h,g){return h*((f=f/g-1)*f*f+1)+a},easeInOutCubic:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f*f+a}return h/2*((f-=2)*f*f+2)+a},easeInQuart:function(e,f,a,h,g){return h*(f/=g)*f*f*f+a},easeOutQuart:function(e,f,a,h,g){return -h*((f=f/g-1)*f*f*f-1)+a},easeInOutQuart:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f*f*f+a}return -h/2*((f-=2)*f*f*f-2)+a},easeInQuint:function(e,f,a,h,g){return h*(f/=g)*f*f*f*f+a},easeOutQuint:function(e,f,a,h,g){return h*((f=f/g-1)*f*f*f*f+1)+a},easeInOutQuint:function(e,f,a,h,g){if((f/=g/2)<1){return h/2*f*f*f*f*f+a}return h/2*((f-=2)*f*f*f*f+2)+a},easeInSine:function(e,f,a,h,g){return -h*Math.cos(f/g*(Math.PI/2))+h+a},easeOutSine:function(e,f,a,h,g){return h*Math.sin(f/g*(Math.PI/2))+a},easeInOutSine:function(e,f,a,h,g){return -h/2*(Math.cos(Math.PI*f/g)-1)+a},easeInExpo:function(e,f,a,h,g){return(f==0)?a:h*Math.pow(2,10*(f/g-1))+a},easeOutExpo:function(e,f,a,h,g){return(f==g)?a+h:h*(-Math.pow(2,-10*f/g)+1)+a},easeInOutExpo:function(e,f,a,h,g){if(f==0){return a}if(f==g){return a+h}if((f/=g/2)<1){return h/2*Math.pow(2,10*(f-1))+a}return h/2*(-Math.pow(2,-10*--f)+2)+a},easeInCirc:function(e,f,a,h,g){return -h*(Math.sqrt(1-(f/=g)*f)-1)+a},easeOutCirc:function(e,f,a,h,g){return h*Math.sqrt(1-(f=f/g-1)*f)+a},easeInOutCirc:function(e,f,a,h,g){if((f/=g/2)<1){return -h/2*(Math.sqrt(1-f*f)-1)+a}return h/2*(Math.sqrt(1-(f-=2)*f)+1)+a},easeInElastic:function(f,h,e,l,k){var i=1.70158;var j=0;var g=l;if(h==0){return e}if((h/=k)==1){return e+l}if(!j){j=k*0.3}if(g<Math.abs(l)){g=l;var i=j/4}else{var i=j/(2*Math.PI)*Math.asin(l/g)}return -(g*Math.pow(2,10*(h-=1))*Math.sin((h*k-i)*(2*Math.PI)/j))+e},easeOutElastic:function(f,h,e,l,k){var i=1.70158;var j=0;var g=l;if(h==0){return e}if((h/=k)==1){return e+l}if(!j){j=k*0.3}if(g<Math.abs(l)){g=l;var i=j/4}else{var i=j/(2*Math.PI)*Math.asin(l/g)}return g*Math.pow(2,-10*h)*Math.sin((h*k-i)*(2*Math.PI)/j)+l+e},easeInOutElastic:function(f,h,e,l,k){var i=1.70158;var j=0;var g=l;if(h==0){return e}if((h/=k/2)==2){return e+l}if(!j){j=k*(0.3*1.5)}if(g<Math.abs(l)){g=l;var i=j/4}else{var i=j/(2*Math.PI)*Math.asin(l/g)}if(h<1){return -0.5*(g*Math.pow(2,10*(h-=1))*Math.sin((h*k-i)*(2*Math.PI)/j))+e}return g*Math.pow(2,-10*(h-=1))*Math.sin((h*k-i)*(2*Math.PI)/j)*0.5+l+e},easeInBack:function(e,f,a,i,h,g){if(g==undefined){g=1.70158}return i*(f/=h)*f*((g+1)*f-g)+a},easeOutBack:function(e,f,a,i,h,g){if(g==undefined){g=1.70158}return i*((f=f/h-1)*f*((g+1)*f+g)+1)+a},easeInOutBack:function(e,f,a,i,h,g){if(g==undefined){g=1.70158}if((f/=h/2)<1){return i/2*(f*f*(((g*=(1.525))+1)*f-g))+a}return i/2*((f-=2)*f*(((g*=(1.525))+1)*f+g)+2)+a},easeInBounce:function(e,f,a,h,g){return h-jQuery.easing.easeOutBounce(e,g-f,0,h,g)+a},easeOutBounce:function(e,f,a,h,g){if((f/=g)<(1/2.75)){return h*(7.5625*f*f)+a}else{if(f<(2/2.75)){return h*(7.5625*(f-=(1.5/2.75))*f+0.75)+a}else{if(f<(2.5/2.75)){return h*(7.5625*(f-=(2.25/2.75))*f+0.9375)+a}else{return h*(7.5625*(f-=(2.625/2.75))*f+0.984375)+a}}}},easeInOutBounce:function(e,f,a,h,g){if(f<g/2){return jQuery.easing.easeInBounce(e,f*2,0,h,g)*0.5+a}return jQuery.easing.easeOutBounce(e,f*2-g,0,h,g)*0.5+h*0.5+a}});
    /* Switch Day - Night Mode */
	const switchTheme = () => {
    const rootElem=document.documentElement;
        let dataTheme=rootElem.getAttribute('data-theme'), newTheme;
        newTheme = (dataTheme === 'light') ? 'dark' : 'light';
        rootElem.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    }
	document.querySelector('#dark-mode-switcher').addEventListener('click', switchTheme);
    /* http://benalman.com/projects/jquery-replacetext-plugin */
    (function($){$.fn.replaceText=function(b,a,c){return this.each(function(){var f=this.firstChild,g,e,d=[];if(f){do{if(f.nodeType===3){g=f.nodeValue;e=g.replace(b,a);if(e!==g){if(!c&&/</.test(e)){$(f).before(e);d.push(f)}else{f.nodeValue=e}}}}while(f=f.nextSibling)}d.length&&$(d).remove()})}})(jQuery);
      //]]>
    </script>
<script>
      //<![CDATA[
        $(function(){"use strict";var minimumWidth;if(Modernizr.mq('(min-width: 0px)')){minimumWidth=function(width){return Modernizr.mq('(min-width: '+width+'px)');}}else{minimumWidth=function(width){return $window.width()>=width;}}$(window).scroll(function(){var scroll=$(window).scrollTop();if(scroll>300&minimumWidth(1200)){$(".fbt_sticky_nav").addClass("sticky__nav");}else{$(".fbt_sticky_nav").removeClass("sticky__nav");}if(scroll>400&minimumWidth(1200)){$(".fbt_sticky_nav").addClass("nav_offset");}else{$(".fbt_sticky_nav").removeClass("nav_offset");}if(scroll>500&minimumWidth(1200)){$(".fbt_sticky_nav").addClass("scrolling_nav");}else{$(".fbt_sticky_nav").removeClass("scrolling_nav");}});$('.post-body').each(function(){$(this).find('iframe[src*="youtube.com"]').removeAttr('width').removeAttr('height').removeAttr('data-thumbnail-src').removeAttr('frameborder').removeClass('YOUTUBE-iframe-video');$(this).find('iframe[src*="youtube.com"], iframe[src*="player.vimeo.com"], iframe[src*="facebook.com/plugins/video"]').addClass('embed-responsive-item').wrap('<div class="embed-responsive embed-responsive-16by9"></div>');});if($('.item-view .post-body img').first().parent().parent().hasClass('separator')){$('.item-view .post-body img').first().parent().parent().addClass('d-none');}$('.item-view .post-body img').first().each(function(){$(this).remove();});$("#navbar.navbar-collapse").each(function(){$(this).find('#LinkList1 ul li').css('cssText','display: block');$(this).find(".navbar-nav li").addClass("nav-item");$(this).find(".navbar-nav li a").addClass("nav-link");$(this).find(".dropdown-menu").parent("li").addClass("dropdown");$(this).find(".dropdown-menu a").removeClass("nav-link").addClass("dropdown-item").unwrap();$(this).find(".dropdown ul").replaceWith(function(){return"<div class='dropdown-menu'>"+this.innerHTML+"</div>";});$(this).find(".dropdown .nav-link").addClass("dropdown-toggle").attr("aria-haspopup","true").attr("aria-expanded","false").attr("data-toggle","dropdown");$(this).find(".navbar-nav").unwrap();});});(function($){"use strict";SearchFormInit();BackToTopInit();HeaderAdInit();function SearchFormInit(){$(".search-trigger").on('click',function(){$("#search").addClass("active").find(".search").focus();});$("#search").on('click',function(){$(this).find(".search").focus();});$("#close").on('click',function(){$("#search").removeClass("active");});};function BackToTopInit(){var $backToTop=$('#BackToTop');$(window).on('scroll',function(){$(this).scrollTop()>=200?$backToTop.show(10).animate({bottom:'15px'},10):$backToTop.animate({bottom:'-50px'},10)});$backToTop.on('click',function(e){e.preventDefault();$('html, body').animate({scrollTop:0},1200,"easeOutExpo")});};function HeaderAdInit(){var adHeight=$('.img-iframe').innerHeight();$('.fbt-top-header-ad').css('padding-top',adHeight);$(window).on('resize',function(){var adHeight=$('.img-iframe').innerHeight();$('.fbt-top-header-ad').css('padding-top',adHeight);});}})(jQuery);if($('.slider-container-row').hasClass('no-items')){$('.blog-wtitle').remove();$('header').css('margin-bottom','calc(var(--grid-gap) - 10px)');$('.canvas .fbt-index-post-wrap .fbt-index-post:nth-child(1) .fbt-post-thumbnail').css('padding-top','42%');};if($('.slider-container-row #HTML1').children().hasClass('hero-message')){$('.blog-wtitle').remove();};if($('.queryMessage').children().hasClass('fbt-query-error-mode')){$('#blog-pager').addClass('d-none');$('.load-more-posts').addClass('d-none');$('#sidebar-wrapper').addClass('d-none');};$("#blog-pager").hide();var olderPosts=$("a.blog-pager-older-link").attr("href");olderPosts&&$(".load-more-posts").show(),$(".load-more").show(),$(".load-more").on("click",function(o){$.ajax({url:olderPosts,success:function(o){var e=$(o).find(".blog-posts");e.children(".status-msg-wrap").remove(),$(".blog-posts").append(e.html()),(olderPosts=$(o).find(".blog-pager-older-link").attr("href"))?$("span.show-more-items").text(loadmore_txt):($(".load-more").hide(),$(".load-more-posts").hide(),$("span.show-more-items").hide());},beforeSend:function(){$(".load-more > #load-icon").show();$(".show-more-items").hide();},complete:function(){$(".load-more > #load-icon").hide(),$(".show-more-items").show();$(function(){var map={};$(".fbt-index-post").each(function(){var value=$(this).find("a").attr("href");if(map[value]==null){map[value]=true;}else{$(this).remove();}});});},}),o.preventDefault();});$(function($){"use strict";var c_form="[contact_Form]";var full_page="[no_Sidebar]";var full_page_hero="[Hero_no_Sidebar]";var sidebar_left="[left_Sidebar]";var primary_button="[button_primary]";var secondary_button="[button_secondary]";var success_button="[button_success]";var danger_button="[button_danger]";var warning_button="[button_warning]";var info_button="[button_info]";var dark_button="[button_dark]";var advertise="[ad]";$(".post-body *").replaceText(primary_button,"<span class='post-button-primary d-none'></span>");$(".post-body *").replaceText(secondary_button,"<span class='post-button-secondary d-none'></span>");$(".post-body *").replaceText(success_button,"<span class='post-button-success d-none'></span>");$(".post-body *").replaceText(danger_button,"<span class='post-button-danger d-none'></span>");$(".post-body *").replaceText(warning_button,"<span class='post-button-warning d-none'></span>");$(".post-body *").replaceText(info_button,"<span class='post-button-info d-none'></span>");$(".post-body *").replaceText(dark_button,"<span class='post-button-dark d-none'></span>");$(".post-button-primary").parent().wrapInner('<button class="btn btn-primary" type="button"></button>');$(".post-button-secondary").parent().wrapInner('<button class="btn btn-secondary" type="button"></button>');$(".post-button-success").parent().wrapInner('<button class="btn btn-success" type="button"></button>');$(".post-button-danger").parent().wrapInner('<button class="btn btn-danger" type="button"></button>');$(".post-button-warning").parent().wrapInner('<button class="btn btn-warning" type="button"></button>');$(".post-button-info").parent().wrapInner('<button class="btn btn-info" type="button"></button>');$(".post-button-dark").parent().wrapInner('<button class="btn btn-dark" type="button"></button>');$(".fbt-item-post *").replaceText(full_page,"<style>#sidebar-wrapper {display: none;}.fbt-item-thumbnail-single {margin-left: calc( 50% - 50vw);margin-right: calc( 50% - 50vw);max-width: 100vw;position: relative;z-index: 1;border-radius: 0!important;padding-top: 62%;overflow: hidden;}.fbt-item-thumbnail-single img {position: absolute;top: 0;left: 0;right: 0;bottom: 0;}.featuredImageContainer {margin-top: calc(0px - var(--header-margin));}@media (max-width: 991.98px){.featuredImageContainer {margin-top: calc(0px - var(--header-margin) + 20px);}}</style>");$(".fbt-item-post *").replaceText(full_page_hero,"<style>#sidebar-wrapper {display: none;}.featuredImageContainer {position: relative;}@media (min-width: 992px){.featuredImageContainer .fbt-item-caption {position: absolute;top: 50%;transform: translateY(-50%);z-index: 1;text-align: center;}.fbt-item-thumbnail-single::before {content: '';position: absolute;top: 0;left: 0;width: 100%;height: 100%;background: rgba(0,0,0,0.35);z-index: 1;}.featuredImageContainer .fbt-item-caption * {color: var(--white)!important;}}.fbt-item-thumbnail-single {margin-left: calc( 50% - 50vw);margin-right: calc( 50% - 50vw);max-width: 100vw;position: relative;z-index: 1;border-radius: 0!important;padding-top: 68%;overflow: hidden;}.fbt-item-thumbnail-single img {position: absolute;top: 0;left: 0;right: 0;bottom: 0;}.featuredImageContainer {margin-top: calc(0px - var(--header-margin));}@media (max-width: 991.98px){.featuredImageContainer {margin-top: calc(0px - var(--header-margin) + 20px);}}</style>");$(".fbt-item-post *").replaceText(sidebar_left,"<style>@media (min-width: 992px) {#sidebar-wrapper {order: 1;}.fbt-main-wrapper {order: 2;}}@media (min-width: 1200px) {.sidebar-wrapper__content.pl-xl-4{padding-left: 0!important;padding-right: 1.5rem!important;}.canvas-modern .sidebar-wrapper .sidebar-wrapper__content{padding-left: 0!important;padding-right: 3rem!important;}[dir='rtl'] .sidebar-wrapper__content.pl-xl-4{padding-left: 1.5rem!important;padding-right: 0!important;}[dir='rtl'] .canvas-modern .sidebar-wrapper .sidebar-wrapper__content{padding-right: 0!important;padding-left: 3rem!important;}}</style>");$(".fbt-item-post *").replaceText(c_form,"<div class='page-contact'/><style>.mauro-options .ContactForm,.sidebar .ContactForm,.ContactForm .fbt-sep-title {display: none!important;}</style>");$(".sidebar .widget *").replaceText(advertise,"<span class='ad_block'/>");$('.mauro-options .ContactForm').appendTo('.page-contact');$(".post-body").each(function(){$(this).find('blockquote').wrapInner('<div class="card border-0 px-5 pt-5 pb-4"><p class="pl-5 position-relative"/></div>');});$('.sidebar .widget:last-child').addClass('fbt-sticky-content sticky-top');$('.sidebar .widget').each(function(){$(this).find('.ad_block').parent().addClass('ad_title').removeClass('title-heading-left').unwrap();$(this).find(".ad_title").replaceWith(function(){return"<span class='fbt-ad-title'>"+this.innerHTML+"</span>";});$(this).find('.fbt-ad-title').parent().addClass('fbt-ad-block');$('.fbt-ad-block').wrapInner('<div class="fbt_ad text-center"/>');$('.fbt-ad-block img').addClass('img-fluid');});(function(){var navSearchTrigger=$('.search-trigger'),navSearchTriggerIcon=$('.nav__search').find('span'),navSearchBox=$('.nav__search-box');navSearchTrigger.on('click',function(e){e.preventDefault();navSearchTriggerIcon.toggleClass('fbt-close-icon');navSearchBox.slideToggle();});})();});$(function(){"use strict";$('#nav__search-box').clone().removeClass('nav__search-box').addClass('d-block d-lg-none my-2').appendTo('.navbar-collapse');$('#mauro-options #Header2').clone().appendTo('.navbar-brand').addClass('light-logo');});
      //]]>
    </script>


</body>

<!-- Mirrored from mauro-modern-fbt.blogspot.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 01 Feb 2024 16:56:13 GMT -->
</html>